# BPF RFS policies on CPUMAP

This is the external policy/controller repository for the optional ordered
CPUMAP kernel prototype. The kernel provides socket storage access, CPU queues,
ordering domains and completion snapshots. This repository selects CPUs and
manages policy lifetime. It is a local development repository; no upstream
acceptance or published GitHub URL is implied.

Implemented policies are stable tuple hashing, socket CPU affinity (TCP, UDP,
MPTCP and SCTP), and optional LLC load avoidance. Hardware intents can follow
the selected CPU or the socket CPU directly. A separate RXNFC controller maps
those CPU IDs to explicitly configured NIC RX queues. No scheduler-private
interface or CONFIG_RPS dependency is introduced.

The default data path retains ordered domains on lookup misses and allocation
failures in the socket-hint map. CPUMAP congestion/allocation failures can drop
packets; CPU offline is an exceptional boundary, as with native RFS. This is
not a lossless queue or a watchdog for arbitrary BPF policies.

## Build

Required: the companion kernel changes, BTF, a BPF-capable clang, bpftool,
libbpf headers/library, libelf and zlib. For SCTP hints, build/load SCTP with the
new `bpf_xdp_sctp_lookup` and `bpf_sctp_release` kfuncs before loading the
policy. Without these kfuncs, SCTP packets use the same ordered hash fallback.
MPTCP uses the existing subflow-to-master helper.

```sh
make CLANG=clang-18 BPFTOOL=/path/to/bpftool VMLINUX_BTF=/path/to/vmlinux
```

Override `LIBBPF_CFLAGS` and `LIBBPF_LIBS` for a private libbpf build.
`VMLINUX_BTF` must come from a completed build; do not point a build at an
actively relinking vmlinux. `build/xdp_rfs -h` lists options.

## Run

Use a dedicated test interface, bring it down, and disable native RPS/RFS on
every RX queue. The loader verifies these conditions, rejects an existing XDP
program and checks native VLAN stripping. It attaches its tracing observers
and creates CPUMAP workers before reporting `ready`; then bring the interface
up. Stop the generator and bring the interface down before terminating the
loader. It drains ordered domains before conditional detach. If drain fails,
the XDP program/maps remain attached for recovery.

```sh
build/xdp_rfs -i eth1 -c 2,3,4,5                # socket CPU policy
build/xdp_rfs -i eth1 -c 2,3,4,5 -p llc-load    # load-aware LLC policy
```

`-S` selects generic XDP for functional testing. Native XDP requires driver
support. The configured CPU vector is immutable; online/offline eligibility
is reconciled using CPU uevents and periodic snapshots. Returning CPUs get new
CPUMAP entries/workers. A lost event stream triggers rebuilding online entries.
CPU uevents require a netns owned by the initial user namespace; this loader
does not promise hotplug recovery inside independently owned user namespaces.

For hardware controls and their ownership contract, see
[hardware.md](docs/hardware.md). Software policy details and boundaries are in
[policy.rst](docs/policy.rst). Five-group performance collection is described in
[bench/README.md](bench/README.md). No physical benchmark results are supplied.

## Tests

```sh
python3 -m unittest discover -s tests -p 'test_*.py' -v
python3 tests/build.py --kernel-src /path/to/kernel \
  --vmlinux /path/to/completed/vmlinux --output /path/to/test-build
```

The second command builds a selected `test_progs` runner using this repository's
actual BPF policy. Run it on the matching test kernel, with at least three
online CPUs and SCTP/MPTCP enabled. Tests assert socket hint use, CPU movement,
delivery/order, stale load handling, dwell/hysteresis and full hardware-intent
map fallback. Kernel selftests separately cover the ordering primitive and
SCTP reference lifetime. The loader/hotplug/pin shell tests are for isolated
four-CPU VMs; they change guest CPU state and network namespaces. Do not run
them on a production host. Hardware unit tests use a fault-injectable backend;
they do not validate NIC firmware or physical queue matching.
