# Reproducible receive-steering comparisons

No physical NIC or traffic-generator results are included. QEMU validates
functionality; its timings are not line-rate performance measurements.

Use the same kernel (with CONFIG_RPS=y for the native baseline), NIC, firmware,
RSS indirection, IRQ affinity, application CPU placement, MTU, packet mix,
offloads, queue sizes and traffic-generator settings for every group. Save the
kernel configuration and patch/archive identity alongside the output. Disable
irqbalance or hold an explicitly documented affinity policy. Repeat each group
at least five times after warmup and vary the order to expose thermal/load drift.

| Group | Preparation on the receiver |
| --- | --- |
| no-xdp | No XDP program, native RPS/RFS disabled; retain documented RSS |
| plain-cpumap | `xdp_rfs -U -p hash -i DEVICE -c CPU_LIST` |
| lookup-storage | `xdp_rfs -U -p lookup -i DEVICE -c CPU_LIST` |
| ordered-cpumap | `xdp_rfs -p lookup -i DEVICE -c CPU_LIST` for barrier cost; also measure `-p rfs` for placement benefit |
| native-rfs | No XDP, configure `rps_cpus`, global `rps_sock_flow_entries` and each queue's `rps_flow_cnt` explicitly |

`-U` intentionally uses ordinary CPUMAP and supplies no ordering/drain guarantee.
It is a measurement mode. Quiesce the generator and stop the interface before
switching groups. Loader startup/shutdown always requires the interface down.
The lookup mode reads the same socket hints but preserves hash placement, which
separates lookup cost from a changed CPU-distribution benefit. Use identical
flow/hash seeds (``-s 1234``) for paired measurements; production seeds are random.

`measure.py` only observes the configured experiment. It does not change NIC,
XDP, RPS, IRQ or system settings and never connects to another host. Example:

```sh
python3 bench/measure.py --device eth1 --label ordered-cpumap \
  --environment physical --cpus 0-7 --duration 30 --output results/ordered-01
```

Optional `--workload-json '["/path/to/receiver", "argument"]'` starts a local
receiver and stops its process group after the observation interval. Arrange
the generator independently. Account for receiver startup in warmup and reject
runs with early workload failures. Choose measured CPUs to cover IRQs, CPUMAP
workers and the application. System-wide cycles include unrelated work on those
CPUs; isolate them or report that noise. `perf` absence/permission/hardware event
failure yields missing values, not zero-cost claims. Kernel metadata, command
errors, pre/post counters and raw perf output are preserved.

`device_rx_pps` is a device counter rate, not application delivery throughput.
Provide an application packet report via `--packet-report report.json` with
optional `latency_us` and `migration_us` sample arrays, plus sent/received,
duplicates/out-of-order and loss counts. P99 uses linear interpolation. Missing
samples yield null. Synchronize clocks for one-way latency, or label RTT samples
as RTT. Preserve generator logs and offered load, and report receive loss as a
fraction of offered packets, including NIC ring drops (driver ethtool counters).

Collect `xdp_cpumap_enqueue`, `xdp_cpumap_kthread` and stack/GRO tracepoint data
in a separate instrumented repetition; per-packet tracing changes the result.
Report frame versus skb paths, GRO segment distribution, domain count/collisions,
lock contention, migrations and CPU hotplug separately. Exercise both stable
placement and deliberate application CPU changes. An 8-CPU LLC experiment
should include competing socket users, load changes and the `llc-load` policy.

Hardware tests additionally record exact RXNFC rules, CPU→RX queue mapping and
driver readback. Verify that queue hits follow installed rules with per-queue
NIC counters. A successful ioctl/readback is control-plane evidence and does
not prove that traffic matched the rule. RX queue migration can reorder packets
before XDP; the software ordering contract starts at the XDP/CPUMAP boundary.
