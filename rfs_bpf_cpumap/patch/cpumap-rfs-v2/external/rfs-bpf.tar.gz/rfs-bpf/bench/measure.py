#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0
"""Capture one already configured receive-steering benchmark, without changing NIC state."""
import argparse
import json
import math
import os
from pathlib import Path
import platform
import shutil
import signal
import subprocess
import time


def capture(command):
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=15)
        return {'argv': command, 'exit': result.returncode,
                'stdout': result.stdout, 'stderr': result.stderr}
    except (OSError, subprocess.TimeoutExpired) as error:
        return {'argv': command, 'error': str(error)}


def counters(device):
    base = Path('/sys/class/net') / device / 'statistics'
    result = {name: int((base / name).read_text()) for name in
              ('rx_packets', 'rx_bytes', 'rx_dropped', 'rx_errors', 'tx_packets')}
    softnet = [line.split() for line in Path('/proc/net/softnet_stat').read_text().splitlines()]
    result['softnet_dropped'] = sum(int(row[1], 16) for row in softnet)
    result['softnet_time_squeeze'] = sum(int(row[2], 16) for row in softnet)
    return result


def percentile(values, percentage):
    if not values:
        return None
    values = sorted(values)
    rank = (len(values) - 1) * percentage / 100
    lower = int(rank)
    return values[lower] + (values[min(lower + 1, len(values) - 1)] - values[lower]) * (rank - lower)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--device', required=True)
    parser.add_argument('--label', required=True, choices=('no-xdp', 'plain-cpumap',
                        'lookup-storage', 'ordered-cpumap', 'native-rfs', 'llc-load', 'rxnfc'))
    parser.add_argument('--environment', choices=('physical', 'virtual'), required=True)
    parser.add_argument('--cpus', required=True, help='perf CPU list including IRQ, CPUMAP and application CPUs')
    parser.add_argument('--duration', type=float, default=30)
    parser.add_argument('--output', type=Path, required=True, help='new directory for this run')
    parser.add_argument('--workload-json', help='optional JSON argv array; no shell evaluation')
    parser.add_argument('--packet-report', type=Path, help='workload JSON with latency_us/migration_us arrays and loss/order counts')
    args = parser.parse_args()
    if not math.isfinite(args.duration) or args.duration <= 0 or '/' in args.device:
        parser.error('invalid duration or interface')
    args.output.mkdir(parents=True, exist_ok=False)
    interface = Path('/sys/class/net') / args.device
    metadata = {'label': args.label, 'environment': args.environment, 'device': args.device,
                'kernel': platform.uname()._asdict(), 'cpus': args.cpus,
                'duration_requested': args.duration, 'created_ns': time.time_ns(),
                'commands': [capture(command) for command in (
                    ['ip', '-j', '-d', 'link', 'show', 'dev', args.device],
                    ['ethtool', '-i', args.device], ['ethtool', '-k', args.device],
                    ['ethtool', '-l', args.device], ['ethtool', '-x', args.device],
                    ['lscpu', '-J'])],
                'rps': {str(path.relative_to(interface)): path.read_text().strip()
                        for pattern in ('queues/rx-*/rps_cpus', 'queues/rx-*/rps_flow_cnt')
                        for path in interface.glob(pattern)}}
    for name in ('interrupts', 'softirqs', 'stat', 'net/softnet_stat'):
        (args.output / ('before-' + name.replace('/', '-'))).write_text(Path('/proc', name).read_text())
    (args.output / 'metadata.json').write_text(json.dumps(metadata, indent=2))
    workload = perf = None
    workload_log = (args.output / 'workload.log').open('w')
    perf_log = (args.output / 'perf.log').open('w')
    (args.output / 'before-driver-stats.json').write_text(
        json.dumps(capture(['ethtool', '-S', args.device]), indent=2))
    start = time.monotonic()
    before = counters(args.device)
    try:
        if args.workload_json:
            command = json.loads(args.workload_json)
            if not isinstance(command, list) or not command or not all(isinstance(s, str) for s in command):
                raise ValueError('workload must be a JSON array of command arguments')
            workload = subprocess.Popen(command, stdout=workload_log, stderr=subprocess.STDOUT, start_new_session=True)
        if shutil.which('perf'):
            perf = subprocess.Popen(['perf', 'stat', '-a', '-C', args.cpus, '-x', ';',
                                     '-o', str(args.output / 'perf.csv'), '-e', 'cycles,instructions',
                                     '--', 'sleep', str(args.duration)], stdout=perf_log, stderr=subprocess.STDOUT)
        time.sleep(args.duration)
    finally:
        after = counters(args.device)
        elapsed = time.monotonic() - start
        if workload and workload.poll() is None:
            os.killpg(workload.pid, signal.SIGTERM)
            try:
                workload.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(workload.pid, signal.SIGKILL)
                workload.wait()
        if perf:
            try:
                perf.wait(timeout=5)
            except subprocess.TimeoutExpired:
                perf.terminate()
                perf.wait(timeout=5)
        workload_log.close()
        perf_log.close()
    (args.output / 'after-driver-stats.json').write_text(
        json.dumps(capture(['ethtool', '-S', args.device]), indent=2))
    delta = {key: after[key] - before[key] for key in before}
    reset = any(value < 0 for value in delta.values())
    perf_events = {}
    if (args.output / 'perf.csv').exists():
        for line in (args.output / 'perf.csv').read_text().splitlines():
            fields = line.split(';')
            if len(fields) >= 3 and fields[2] in ('cycles', 'instructions'):
                try:
                    perf_events[fields[2]] = float(fields[0])
                except ValueError:
                    pass
    packet = None
    if args.packet_report:
        packet = json.loads(args.packet_report.read_text())
        (args.output / 'packet-report.json').write_text(json.dumps(packet, indent=2))
    result = {'label': args.label, 'environment': args.environment, 'seconds': elapsed,
              'counter_reset': reset, 'counters': delta,
              'device_rx_pps': None if reset else delta['rx_packets'] / elapsed,
              'perf': perf_events, 'cycles_per_device_rx_packet':
              perf_events.get('cycles', 0) / delta['rx_packets']
              if not reset and delta['rx_packets'] and 'cycles' in perf_events else None,
              'p99_us': percentile(packet.get('latency_us', []), 99) if packet else None,
              'migration_p99_us': percentile(packet.get('migration_us', []), 99) if packet else None,
              'workload_returncode': workload.returncode if workload else None,
              'perf_returncode': perf.returncode if perf else None}
    (args.output / 'result.json').write_text(json.dumps(result, indent=2))
    for name in ('interrupts', 'softirqs', 'stat', 'net/softnet_stat'):
        (args.output / ('after-' + name.replace('/', '-'))).write_text(Path('/proc', name).read_text())
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
