# Hardware RFS and socket-directed ntuple rules

The backend uses existing ethtool RXNFC (`GRXCLSRULE`, `SRXCLSRLINS`,
`SRXCLSRLDEL`) with exact TCP/UDP/SCTP IPv4/IPv6 tuples. It accelerates RFS-like
placement through NIC queues and can follow the socket CPU independently of
the software placement policy. It does **not** invoke native
`ndo_rx_flow_steer` or reuse native aRFS filter IDs/expiration callbacks. That
separate driver lifecycle would require its own ownership and acknowledgement
interface; these are not silently inferred from an integer filter ID.

`-H PIN_DIR` enables a bounded BPF flow-intent map and pins its control maps in
a new private bpffs directory. `-N` makes hardware intents follow the socket
CPU; otherwise they follow the software policy CPU. Intents are only offered
when a socket CPU hint exists in the allowed CPU set. They contain a tuple,
CPU, generation and last-observed time. Updates are rate-limited to 100 ms
while the CPU is stable. Generation changes and snapshots use BPF spin locks;
the controller reads with `BPF_F_LOCK`. No ethtool operation runs in BPF or in
the receive softirq. Disabled hardware mode has no packet-path map lookup.

Example preparation (replace all interface, CPU, queue and location values
with an explicit device plan):

```sh
# With ingress down and native RPS/RFS disabled:
build/xdp_rfs -i eth1 -c 2,3 -H /sys/fs/bpf/rfs-eth1 -N
# In another shell, in the same network namespace:
python3 tools/hw_steer.py --device eth1 --maps /sys/fs/bpf/rfs-eth1 \
  --cpu-queues 2:0,3:1 --locations 64:32 --exclusive-range \
  --journal /var/lib/rfs-bpf/eth1.json
```

Create the journal parent as a private directory first. The driver must
support explicit RXNFC locations, query, insertion and deletion. The tool
does not turn on ntuple/offloads or change RSS/IRQ affinity automatically.
CPU→queue mapping is configuration, not a claim that CPU IDs equal RX queue
IDs. Keep IRQ/NAPI affinity and queue layout consistent with that mapping.
Ingress may be brought up after the loader is ready. Only dedicated untagged
test traffic with direct IP demux is currently supported; VLAN, tunnels,
fragments, VRF and DNAT paths need separate classification/metadata work.

RXNFC has no owner token or conditional update. The operator must reserve the
chosen range exclusively against ethtool, other agents and native aRFS.
There is one process lock per interface plus a journal lock. Existing or
changed rules are retained and reported. Read-before-write cannot make an
uncooperative concurrent administrator safe; the exclusive-writer contract is
essential. A slot conflict is not permission to overwrite a rule.

The controller persists an intent and fsyncs it before insertion. A successful
ioctl is followed by exact readback before recording the rule as active.
CPU changes delete and confirm removal of the old rule before installing a
new one. Failed/uncertain operations retain a journal record for recovery.
Deletion reads back ownership, requests deletion, confirms absence, and only
then releases the slot. Each reconciliation admits at most 16 new rules.
Intents expire after 30 seconds by default; map-full/driver-full errors leave
software RFS operational. The controller stops on control errors and attempts
cleanup; restarting first reconciles its durable journal. It does not spin in
a packet callback or claim that a missing acknowledgement succeeded.

Device identity includes netns, ifindex, driver/bus, MAC address and RX queue
count. Changes require explicit review/restart; old journal records are never
blindly replayed to another identity. A reset that empties rules is detected by
readback. Identity cannot prove that an uncooperative writer did not recreate
an identical rule; that is another reason for exclusive range ownership.

On shutdown, stop ingress, terminate the hardware controller and verify clean
rule removal before terminating the loader. The loader then drains/detaches
and removes its pins. For crash recovery, retain the journal and use
`--recover-only` with the same device identity/range; this can remove matching
owned rules without a live BPF policy. A failed cleanup returns an error and
preserves evidence. Do not delete the journal merely to make an error disappear.

Hardware changes the input RX queue; all admitted traffic still traverses the
software CPUMAP barrier. Firmware rule acceptance is not evidence of a packet
hit. Check per-queue NIC counters with real traffic. Multiple RX queues and
hardware rule movement can reorder before the XDP hook: ordered CPUMAP only
orders the packets from its own submission boundary, just like its software
multi-producer contract. There is no new wire-order or NIC-reset guarantee.

The test environment currently has no physical NIC/generator. Controller
transaction/failure and ABI tests are local evidence only; physical placement,
driver races, queue resets and performance remain unmeasured.
