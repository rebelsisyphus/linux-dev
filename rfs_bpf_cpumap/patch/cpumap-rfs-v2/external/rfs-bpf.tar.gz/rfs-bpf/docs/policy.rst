.. SPDX-License-Identifier: GPL-2.0

Programmable receive CPU selection
=================================

This repository contains policies and a loader for XDP with CPUMAP. The
kernel supplies packet transport, optional ordering domains, socket lookup
and socket storage access. Parsing, application CPU observations, load
sampling and CPU selection live outside that mechanism. CONFIG_RPS is not
required. No scheduler policy or scheduler-private load state is accessed.

Policies
--------

``-p rfs`` follows the application's latest eligible socket CPU.
``-p hash`` selects a stable tuple hash without socket lookup or observers.
``-p llc-load`` uses the socket hint to locate the application's LLC and
samples up to eight eligible CPUs there, excluding the application CPU.
``-p lookup`` reads socket hints but retains hash placement, for measuring
lookup/storage cost independently of placement changes.

The load policy consumes /proc/stat snapshots sampled about every 250 ms.
Busy time includes IRQ, softirq and steal time, excludes idle and iowait,
and does not double-count guest time. An EWMA with weight 1/4 smooths it.
Snapshots older than two seconds are ignored. A choice is retained for
500 ms, then an improvement greater than 100/1000 utilization is required
to move. Invalid, offline, changed-LLC or application CPU choices need not
be retained. Missing usable telemetry falls back to socket CPU or hash.
This is advisory utilization, not a capacity guarantee. Eight candidates
need not contain the minimum in a larger LLC; flows can choose the same CPU.

Application observations
------------------------

Tracing observes inet/inet6 sendmsg and recvmsg, inet_splice_eof,
tcp_splice_read and successful inet_accept. MSG_ERRQUEUE is excluded.
MPTCP has additional accept/splice observers on its own protocol operations.
tcp_zerocopy_receive and io_zcrx_recv are optional: the loader reports
and disables an observer when its BTF function is absent. The io_zcrx wrapper
is observed on return, excluding unsupported protocols. Its private TCP
implementation can be inlined without losing this observer. A
disabled observer does not manufacture a hint. Ordinary io_uring operations
are covered when they reach an observed socket operation.

An aligned CPU-plus-one value in socket local storage has last-writer-wins
semantics. It persists until another observation or socket destruction,
matching native RFS's advisory lifetime. Storage allocation occurs on the
application path; XDP only reads it. Allocation failures use hash fallback.

TCP and connected UDP use existing XDP socket lookup. For an MPTCP subflow,
bpf_skc_to_mptcp_sock obtains the master whose storage is read while the
subflow lookup reference remains held. Each subflow has a separate tuple
and ordering domain; MPTCP itself provides data-level ordering across paths.
The empty BTF type supplied by CONFIG_MPTCP=n disables this branch through
CO-RE, so the same policy object still loads for ordinary TCP/UDP.

SCTP uses the optional bpf_xdp_sctp_lookup/bpf_sctp_release pair to find
existing associations, including those on one-to-many sockets. Accept or
peeloff can change the socket after lookup; the reference is safe but the
hint remains advisory. Multihomed associations can have multiple tuple
domains; this is not association-wide ordering across paths. Load modular
SCTP before the policy. Unavailable weak kfuncs select ordered hash fallback.

Ordering and failures
---------------------

The directional address/port/protocol tuple selects one of 4096 fixed
domains independently of socket existence. Lookup/storage failures, socket
recreation and hardware-intent exhaustion do not change domain identity.
Collisions share a migration barrier and may delay CPU changes. There is
no dynamic domain allocator, eviction protocol or domain reassignment.

By default every admitted packet uses bpf_cpumap_redirect. The kernel
atomically retains the old target while source reservations or prior
submissions remain outstanding. Queue pressure and unavailable targets
use the redirect error/drop path, never a local PASS that could overtake
older packets. Completion means synchronous stack handoff after GRO flush,
not application consumption or downstream asynchronous steering completion.
The CPU-offline exception matches native RFS's limited guarantee; neither
lossless delivery nor ordering through hotplug is promised.

``-U`` selects ordinary CPUMAP for baseline measurements and removes the
migration barrier. Do not describe this mode as ordered RFS. The mode and
hash seed are immutable while loaded. ``-s SEED`` fixes a 32-bit seed for
paired measurements; the default seed is random.

This contract does not isolate arbitrary replacement policies. The verifier
checks bounded execution and memory access, but is not an Mpps latency
watchdog. Expensive verified code, policy bypass, administrator interference
and process death are not repaired by a sched_ext-like automatic takeover.

Packet and metadata scope
-------------------------

Supported traffic is direct local Ethernet unicast: nonfragmented IPv4
TCP/UDP/SCTP (IPv4 options allowed), or IPv6 TCP/UDP/SCTP without extension
headers. Required headers must be linear. Truncated headers are dropped.
Other Ethernet protocols, VLAN, fragments and IPv6 extension headers pass
locally. Mixing these into an admitted flow is outside its ordering contract.

The programs use xdp.frags. CPUMAP carries supported multi-buffer packets;
kernel tests check 9000-byte payload integrity. Native XDP needs driver
support. Generic XDP needs the skb MAC-length copy fix accompanying the
kernel series when page-pool copying is used.

The native loader rejects active hardware VLAN stripping and fails if it
cannot check feature state. Tuple hashing does not require an RX hardware
hash. No new RX checksum/hash/VLAN metadata restoration is claimed: native
CPUMAP uses its existing skb construction, and checksums may be validated
again. The stripping guard does not make tagged traffic supported.

Early lookup precedes final demultiplexing. Reuseport, DNAT, VRF, tunnels,
sk_lookup policy and socket-map redirection require their own association
policy. A successful lookup is not proof of eventual socket delivery.

Control and lifetime
--------------------

The loader accepts at most 128 distinct initially online CPUs. It creates
2048-entry queues before attaching, checks native RPS and RFS are disabled
on every RX queue, and refuses existing XDP attachments. Native XDP is the
default; ``-S`` selects generic XDP.

Keep ingress administratively down during startup. Bring it up after
``ready``. Bring it down before SIGINT/SIGTERM and keep it down until exit.
The loader drains all domains, then detaches only its own program. Another
controller must not resume ingress during this window. Map replacement,
domain reassignment and configured CPU-set changes require quiescence;
live policy handover is not implemented.

Hotplug within that fixed CPU set is automatic. The loader subscribes to
kernel uevents before its initial snapshot, withdraws eligibility before
queue deletion/replacement, recreates online workers, then restores
eligibility. A full offline/online cycle between polls is remembered.
Truncation or ENOBUFS causes a conservative rebuild. Kernel-origin events
and periodic online snapshots are checked. This requires the initial user
namespace's uevent visibility; nested user namespaces are not supported for
hotplug control.

On loader death, legacy XDP attachments/maps may remain while tracing links
disappear. Hints can become stale; new sockets use hash fallback. No
recovery service is implied. Stop ingress before manual removal. Hardware
mode also needs the ownership/journal/cleanup protocol in hardware.md.

Build and validation
--------------------

Use the root Makefile with a matching patched kernel BTF image; see
README.md. The external test runner builds the actual policy source plus
TC observation and native packet generators. Kernel selftests retain an
independent small composition program, with no external source dependency.

QEMU, veth/native tests, controller mocks and compile checks establish
different properties. They do not establish physical rule hits, NIC
throughput, production tail latency or multipath protocol performance.
Consult the project validation record for executed results and
bench/README.md for physical measurement procedures.
