// SPDX-License-Identifier: GPL-2.0
#define _GNU_SOURCE
#include <dirent.h>
#include <errno.h>
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <bpf/bpf.h>
#include "load.h"
#include "xdp_rfs.h"

static char *read_line(const char *path)
{
	char *line = NULL;
	size_t len = 0;
	FILE *file = fopen(path, "r");

	if (!file)
		return NULL;
	if (getline(&line, &len, file) < 0) {
		free(line);
		line = NULL;
	}
	fclose(file);
	return line;
}

static char *llc_cpus(unsigned int cpu)
{
	char dir[128], path[PATH_MAX], *list = NULL, *line;
	struct dirent *entry;
	unsigned int best = 0, level;
	DIR *cache;

	snprintf(dir, sizeof(dir), "/sys/devices/system/cpu/cpu%u/cache", cpu);
	cache = opendir(dir);
	if (!cache)
		return NULL;
	while ((entry = readdir(cache))) {
		if (strncmp(entry->d_name, "index", 5))
			continue;
		if (snprintf(path, sizeof(path), "%s/%s/type", dir, entry->d_name) >=
		    (int)sizeof(path))
			continue;
		line = read_line(path);
		if (!line)
			continue;
		level = !strcmp(line, "Unified\n") || !strcmp(line, "Data\n");
		free(line);
		if (!level)
			continue;
		snprintf(path, sizeof(path), "%s/%s/level", dir, entry->d_name);
		line = read_line(path);
		if (!line)
			continue;
		level = strtoul(line, NULL, 10);
		free(line);
		if (level <= best)
			continue;
		snprintf(path, sizeof(path), "%s/%s/shared_cpu_list", dir, entry->d_name);
		line = read_line(path);
		if (!line)
			continue;
		free(list);
		list = line;
		best = level;
	}
	closedir(cache);
	return list;
}

static bool contains_cpu(const char *list, unsigned int cpu)
{
	unsigned long first, last;
	char *end;

	while (*list) {
		first = strtoul(list, &end, 10);
		if (end == list)
			break;
		last = first;
		if (*end == '-') {
			list = end + 1;
			last = strtoul(list, &end, 10);
			if (end == list)
				break;
		}
		if (cpu >= first && cpu <= last)
			return true;
		if (*end != ',')
			break;
		list = end + 1;
	}
	return false;
}

int rfs_init_topology(int map_fd, int possible, const __u32 *cpus, __u32 count)
{
	struct rfs_llc group;
	__u32 cpu, i;
	char *list;
	int err;

	for (cpu = 0; cpu < (__u32)possible; cpu++) {
		list = llc_cpus(cpu);
		if (!list)
			continue;
		memset(&group, 0, sizeof(group));
		/* The lowest sibling ID uniquely identifies a cache instance. */
		group.id = strtoul(list, NULL, 10);
		for (i = 0; i < count; i++) {
			if (contains_cpu(list, cpus[i]))
				group.cpus[group.count++] = cpus[i];
		}
		free(list);
		err = bpf_map_update_elem(map_fd, &cpu, &group, BPF_ANY);
		if (err)
			return -errno;
	}
	for (i = 0; i < count; i++) {
		if (bpf_map_lookup_elem(map_fd, &cpus[i], &group))
			return -errno;
		if (!group.count)
			return -ENODATA;
	}
	return 0;
}

int rfs_sample_load(int map_fd, int possible, struct rfs_cpu_sample *samples)
{
	unsigned long long user, nice, sys, idle, wait, irq, soft, steal, total, busy;
	struct timespec now;
	struct rfs_load value;
	struct rfs_cpu_sample *sample;
	char *line = NULL;
	size_t len = 0;
	__u32 cpu;
	int err = 0;
	FILE *file = fopen("/proc/stat", "r");

	if (!file)
		return -errno;
	clock_gettime(CLOCK_MONOTONIC, &now);
	while (getline(&line, &len, file) >= 0) {
		if (sscanf(line, "cpu%u %llu %llu %llu %llu %llu %llu %llu %llu",
			   &cpu, &user, &nice, &sys, &idle, &wait, &irq, &soft, &steal) != 9 ||
		    cpu >= (__u32)possible)
			continue;
		total = user + nice + sys + idle + wait + irq + soft + steal;
		idle += wait;
		sample = &samples[cpu];
		if (sample->total && total > sample->total && idle >= sample->idle) {
			busy = total - sample->total;
			busy -= (idle - sample->idle < busy) ? idle - sample->idle : busy;
			/* Alpha=1/4; short-term spikes do not cause immediate migration. */
			sample->util = (3 * sample->util +
					1000 * busy / (total - sample->total)) / 4;
			value.util = sample->util;
			value.updated_ms = (__u32)(now.tv_sec * 1000 + now.tv_nsec / 1000000);
			if (bpf_map_update_elem(map_fd, &cpu, &value, BPF_ANY)) {
				err = -errno;
				break;
			}
		}
		sample->total = total;
		sample->idle = idle;
	}
	if (ferror(file))
		err = -EIO;
	free(line);
	fclose(file);
	return err;
}
