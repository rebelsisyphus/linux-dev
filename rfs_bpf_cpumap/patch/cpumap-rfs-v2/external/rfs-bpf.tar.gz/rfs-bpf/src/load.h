/* SPDX-License-Identifier: GPL-2.0 */
#ifndef RFS_LOAD_H
#define RFS_LOAD_H
#include <linux/types.h>

struct rfs_cpu_sample {
	unsigned long long total, idle;
	__u32 util;
};

int rfs_init_topology(int map_fd, int possible, const __u32 *cpus, __u32 count);
int rfs_sample_load(int map_fd, int possible, struct rfs_cpu_sample *samples);
#endif
