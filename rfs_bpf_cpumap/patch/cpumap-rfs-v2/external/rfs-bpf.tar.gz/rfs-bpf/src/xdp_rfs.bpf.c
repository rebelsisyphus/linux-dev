// SPDX-License-Identifier: GPL-2.0
#include "vmlinux.h"
#include <bpf/bpf_endian.h>
#include <bpf/bpf_core_read.h>
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_tracing.h>
#include "xdp_rfs.h"

#define MSG_ERRQUEUE 0x2000
#define EPROTONOSUPPORT 93

extern int bpf_cpumap_redirect(void *map, __u32 cpu, __u32 domain) __ksym;
extern int bpf_cpumap_get_state(void *map, __u32 domain, void *state,
				__u32 size) __ksym;
extern struct sock *bpf_xdp_sctp_lookup(struct xdp_md *ctx,
					struct bpf_sock_tuple *tuple,
					__u32 tuple__sz) __ksym __weak;
extern void bpf_sctp_release(struct sock *sk) __ksym __weak;

struct {
	__uint(type, BPF_MAP_TYPE_CPUMAP);
	__uint(max_entries, 1);
	__uint(map_extra, RFS_DOMAINS);
	__type(key, __u32);
	__type(value, struct bpf_cpumap_val);
} cpu_map SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, __u32);
} allowed SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_SK_STORAGE);
	__uint(map_flags, BPF_F_NO_PREALLOC);
	__type(key, int);
	__type(value, struct rfs_hint);
} socket_cpu SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_PERCPU_ARRAY);
	__uint(max_entries, RFS_STAT_MAX);
	__type(key, __u32);
	__type(value, __u64);
} stats SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, struct rfs_load);
} cpu_load SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, struct rfs_llc);
} llc SEC(".maps");

struct load_choice {
	struct bpf_spin_lock lock;
	__u32 cpu_plus_one;
	__u32 changed_ms;
};

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, RFS_DOMAINS);
	__type(key, __u32);
	__type(value, struct load_choice);
} load_choices SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_HASH);
	__uint(max_entries, 1024);
	__type(key, struct rfs_flow_key);
	__type(value, struct rfs_hw_flow);
} hw_flows SEC(".maps");

struct {
	__uint(type, BPF_MAP_TYPE_ARRAY);
	__uint(max_entries, 1);
	__type(key, __u32);
	__type(value, struct rfs_hw_config);
} hw_config SEC(".maps");

const volatile __u32 nr_cpus;
const volatile __u32 cpus[RFS_MAX_CPUS];
const volatile __u32 netns_ino;
const volatile __u32 hash_seed;
const volatile __u32 policy;
const volatile bool ordered = true;
/* Zero disables hardware hints; 1 follows policy, 2 follows the socket CPU. */
const volatile __u32 hardware;

/* Only the unattached control program writes these fields. */
__u32 busy_domains;
int query_error;

static __always_inline void count(__u32 key)
{
	__u64 *value = bpf_map_lookup_elem(&stats, &key);

	if (value)
		__sync_fetch_and_add(value, 1);
}

static __always_inline void record_cpu(struct sock *sk)
{
	struct rfs_hint *hint;
	__u32 cpu;
	__u16 protocol;

	if (!sk || sk->__sk_common.skc_net.net->ns.inum != netns_ino)
		return;
	protocol = sk->sk_protocol;
	/* One-to-many SCTP sockets have no single established socket state. */
	if (protocol != IPPROTO_SCTP &&
	    (sk->__sk_common.skc_state != BPF_TCP_ESTABLISHED ||
	     (protocol != IPPROTO_TCP && protocol != IPPROTO_UDP &&
	      protocol != IPPROTO_MPTCP)))
		return;
	hint = bpf_sk_storage_get(&socket_cpu, sk, 0, BPF_SK_STORAGE_GET_F_CREATE);
	if (!hint) {
		count(RFS_STORAGE_FAILURE);
		return;
	}
	cpu = bpf_get_smp_processor_id() + 1;
	if (*(volatile __u32 *)&hint->cpu_plus_one != cpu)
		*(volatile __u32 *)&hint->cpu_plus_one = cpu;
}

SEC("fentry/inet_sendmsg")
int BPF_PROG(rfs_send4, struct socket *sock)
{
	record_cpu(sock->sk);
	return 0;
}

SEC("fentry/inet6_sendmsg")
int BPF_PROG(rfs_send6, struct socket *sock)
{
	record_cpu(sock->sk);
	return 0;
}

SEC("fentry/inet_splice_eof")
int BPF_PROG(rfs_splice_eof, struct socket *sock)
{
	record_cpu(sock->sk);
	return 0;
}

SEC("fentry/inet_recvmsg")
int BPF_PROG(rfs_recv4, struct socket *sock, struct msghdr *msg,
	     size_t size, int flags)
{
	if (!(flags & MSG_ERRQUEUE))
		record_cpu(sock->sk);
	return 0;
}

SEC("fentry/inet6_recvmsg")
int BPF_PROG(rfs_recv6, struct socket *sock, struct msghdr *msg,
	     size_t size, int flags)
{
	if (!(flags & MSG_ERRQUEUE))
		record_cpu(sock->sk);
	return 0;
}

SEC("fexit/inet_accept")
int BPF_PROG(rfs_accept, struct socket *sock, struct socket *newsock,
	     struct proto_accept_arg *arg, int ret)
{
	if (!ret)
		record_cpu(newsock->sk);
	return 0;
}

SEC("fentry/tcp_splice_read")
int BPF_PROG(rfs_splice, struct socket *sock)
{
	record_cpu(sock->sk);
	return 0;
}

SEC("fexit/mptcp_stream_accept")
int BPF_PROG(rfs_mptcp_accept, struct socket *sock, struct socket *newsock,
	     struct proto_accept_arg *arg, int ret)
{
	if (!ret)
		record_cpu(newsock->sk);
	return 0;
}

SEC("fentry/mptcp_splice_read")
int BPF_PROG(rfs_mptcp_splice, struct socket *sock)
{
	record_cpu(sock->sk);
	return 0;
}

SEC("fentry/tcp_zerocopy_receive")
int BPF_PROG(rfs_zerocopy, struct sock *sk)
{
	record_cpu(sk);
	return 0;
}

/* The public wrapper survives inlining; exclude unsupported protocols. */
SEC("fexit/io_zcrx_recv")
int BPF_PROG(rfs_zcrx, void *req, void *ifq, struct socket *sock,
	     unsigned int flags, unsigned int issue_flags, unsigned int *len, int ret)
{
	if (ret != -EPROTONOSUPPORT)
		record_cpu(sock->sk);
	return 0;
}

static __always_inline __u32 mix(__u32 hash, __u32 word)
{
	hash ^= word;
	hash *= 0x9e3779b1;
	return (hash << 13) | (hash >> 19);
}

/* Zero-initialized tuple padding makes the domain independent of lookup. */
static __always_inline __u32 tuple_hash(struct bpf_sock_tuple *tuple,
					__u32 size, __u8 protocol)
{
	__u32 hash = mix(hash_seed, size ^ protocol);
	__u32 word;
	int i;

#pragma unroll
	for (i = 0; i < sizeof(*tuple) / sizeof(word); i++) {
		__builtin_memcpy(&word, (char *)tuple + i * sizeof(word), sizeof(word));
		hash = mix(hash, word);
	}
	hash ^= hash >> 16;
	hash *= 0x85ebca6b;
	hash ^= hash >> 13;
	return hash;
}

static __always_inline bool cpu_allowed(__u32 cpu)
{
	__u32 *value = bpf_map_lookup_elem(&allowed, &cpu);

	return value && *value;
}

/* The immutable vector and domain survive hotplug; only eligibility changes. */
static __always_inline __u32 fallback_cpu(__u32 hash)
{
	__u32 index = hash % nr_cpus;
	__u32 cpu = cpus[index];
	int i;

	if (cpu_allowed(cpu))
		return cpu;
	for (i = 1; i < RFS_MAX_CPUS; i++) {
		if (i >= nr_cpus)
			break;
		index++;
		if (index >= nr_cpus)
			index = 0;
		cpu = cpus[index];
		if (cpu_allowed(cpu))
			return cpu;
	}
	/* Let the ordered primitive retain a usable old target or drop. */
	return cpus[hash % nr_cpus];
}

static __always_inline __u32 load_score(__u32 cpu, __u32 now)
{
	struct rfs_load *load = bpf_map_lookup_elem(&cpu_load, &cpu);

	if (!load || !load->updated_ms || now - load->updated_ms > RFS_LOAD_MAX_AGE_MS)
		return 1001;
	return load->util;
}

static __always_inline __u32 select_load_cpu(__u32 hash, __u32 app, __u32 fallback)
{
	__u32 domain = hash & (RFS_DOMAINS - 1), now = bpf_ktime_get_ns() / 1000000;
	struct rfs_llc *group = bpf_map_lookup_elem(&llc, &app);
	struct load_choice *choice;
	__u32 cpu, best = fallback, score, lowest = 1001;
	struct rfs_llc *old_group;
	__u32 old, old_score;
	__u64 index, n;
	bool retain_old;
	int i;

	if (!group)
		return fallback;
	n = group->count;
	if (!n || n > RFS_MAX_CPUS)
		return fallback;
	index = hash % n;
	for (i = 0; i < RFS_LOAD_CHOICES; i++) {
		if (i >= n || index >= RFS_MAX_CPUS)
			break;
		cpu = group->cpus[index];
		if (cpu != app && cpu_allowed(cpu)) {
			score = load_score(cpu, now);
			if (score < lowest) {
				lowest = score;
				best = cpu;
			}
		}
		index++;
		if (index >= n)
			index = 0;
	}
	if (lowest > 1000)
		return fallback;
	choice = bpf_map_lookup_elem(&load_choices, &domain);
	if (!choice)
		return fallback;
	old = *(volatile __u32 *)&choice->cpu_plus_one;
	retain_old = old && old - 1 != app && cpu_allowed(old - 1);
	cpu = old - 1;
	old_group = bpf_map_lookup_elem(&llc, &cpu);
	retain_old = retain_old && old_group && old_group->id == group->id;
	old_score = retain_old ? load_score(old - 1, now) : 1001;
	/* No helper calls under the policy lock; the kernel barrier is separate. */
	bpf_spin_lock(&choice->lock);
	if (choice->cpu_plus_one != old) {
		best = choice->cpu_plus_one ? choice->cpu_plus_one - 1 : best;
	} else if (retain_old &&
		   (now - choice->changed_ms < RFS_LOAD_HOLD_MS ||
		    lowest + RFS_LOAD_MARGIN >= old_score)) {
		best = old - 1;
	} else if (best + 1 != old) {
		choice->cpu_plus_one = best + 1;
		choice->changed_ms = now;
	}
	bpf_spin_unlock(&choice->lock);
	count(RFS_LOAD_SELECTED);
	return best;
}

static __noinline void offer_hardware(struct bpf_sock_tuple *tuple, __u32 size,
				      __u8 protocol, __u32 cpu)
{
	struct rfs_flow_key key = {};
	struct rfs_hw_flow initial = {}, *flow;
	__u64 now = bpf_ktime_get_ns();

	key.protocol = protocol;
	if (size == sizeof(tuple->ipv4)) {
		key.family = 2;
		__builtin_memcpy(key.saddr, &tuple->ipv4.saddr, 4);
		__builtin_memcpy(key.daddr, &tuple->ipv4.daddr, 4);
		key.sport = tuple->ipv4.sport;
		key.dport = tuple->ipv4.dport;
	} else {
		key.family = 10;
		__builtin_memcpy(key.saddr, tuple->ipv6.saddr, 16);
		__builtin_memcpy(key.daddr, tuple->ipv6.daddr, 16);
		key.sport = tuple->ipv6.sport;
		key.dport = tuple->ipv6.dport;
	}
	flow = bpf_map_lookup_elem(&hw_flows, &key);
	if (!flow) {
		initial.cpu = cpu;
		initial.seen_ns = now;
		initial.generation = 1;
		if (bpf_map_update_elem(&hw_flows, &key, &initial, BPF_NOEXIST))
			count(RFS_HW_FULL);
		return;
	}
	/* Bounded telemetry; hardware errors never change software admission. */
	if (flow->cpu == cpu && now - flow->seen_ns < 100000000)
		return;
	bpf_spin_lock(&flow->lock);
	if (flow->cpu != cpu) {
		flow->cpu = cpu;
		flow->generation++;
	}
	flow->seen_ns = now;
	bpf_spin_unlock(&flow->lock);
}

static __always_inline int rfs_select(struct xdp_md *ctx)
{
	void *data = (void *)(long)ctx->data;
	void *end = (void *)(long)ctx->data_end;
	struct bpf_sock_tuple tuple = {};
	struct ethhdr *eth = data;
	struct rfs_hint *hint;
	struct bpf_sock *sk;
	__u32 size, hash, cpu, observed = 0;
	__u8 protocol;
	void *transport;

	if ((void *)(eth + 1) > end)
		goto drop;
	if (eth->h_dest[0] & 1)
		goto pass;
	if (eth->h_proto == bpf_htons(0x0800)) {
		struct iphdr *ip = (void *)(eth + 1);
		__u32 len;

		if ((void *)(ip + 1) > end || ip->version != 4 || ip->ihl < 5)
			goto drop;
		len = ip->ihl * 4;
		if ((void *)ip + len > end || bpf_ntohs(ip->tot_len) < len)
			goto drop;
		if (ip->frag_off & bpf_htons(0x3fff))
			goto pass;
		protocol = ip->protocol;
		tuple.ipv4.saddr = ip->saddr;
		tuple.ipv4.daddr = ip->daddr;
		size = sizeof(tuple.ipv4);
		transport = (void *)ip + len;
		if (protocol != IPPROTO_TCP && protocol != IPPROTO_UDP &&
		    protocol != IPPROTO_SCTP)
			goto pass;
		if (bpf_ntohs(ip->tot_len) < len + 4 || transport + 4 > end)
			goto drop;
		__builtin_memcpy(&tuple.ipv4.sport, transport, 4);
	} else if (eth->h_proto == bpf_htons(0x86dd)) {
		struct ipv6hdr *ip = (void *)(eth + 1);

		if ((void *)(ip + 1) > end || ip->version != 6)
			goto drop;
		protocol = ip->nexthdr;
		if (protocol != IPPROTO_TCP && protocol != IPPROTO_UDP &&
		    protocol != IPPROTO_SCTP)
			goto pass;
		transport = ip + 1;
		if (bpf_ntohs(ip->payload_len) < 4 || transport + 4 > end)
			goto drop;
		__builtin_memcpy(tuple.ipv6.saddr, &ip->saddr, sizeof(ip->saddr));
		__builtin_memcpy(tuple.ipv6.daddr, &ip->daddr, sizeof(ip->daddr));
		__builtin_memcpy(&tuple.ipv6.sport, transport, 4);
		size = sizeof(tuple.ipv6);
	} else {
		goto pass;
	}

	if (!nr_cpus || nr_cpus > RFS_MAX_CPUS)
		goto drop;
	hash = tuple_hash(&tuple, size, protocol);
	if (policy == RFS_POLICY_HASH) {
		cpu = fallback_cpu(hash);
		count(RFS_FALLBACK);
		goto redirect;
	}
	if (protocol == IPPROTO_SCTP) {
		if (bpf_ksym_exists(bpf_xdp_sctp_lookup) &&
		    bpf_ksym_exists(bpf_sctp_release)) {
			struct sock *sctp_sk = bpf_xdp_sctp_lookup(ctx, &tuple, size);

			if (sctp_sk) {
				hint = bpf_sk_storage_get(&socket_cpu, sctp_sk, 0, 0);
				if (hint)
					observed = *(volatile __u32 *)&hint->cpu_plus_one;
				bpf_sctp_release(sctp_sk);
			}
		}
		goto choose;
	}
	if (protocol == IPPROTO_TCP)
		sk = bpf_sk_lookup_tcp(ctx, &tuple, size, BPF_F_CURRENT_NETNS, 0);
	else
		sk = bpf_sk_lookup_udp(ctx, &tuple, size, BPF_F_CURRENT_NETNS, 0);
	if (sk) {
		if (sk->state == BPF_TCP_ESTABLISHED) {
			struct mptcp_sock *msk = NULL;

			/* CONFIG_MPTCP=n exposes an empty BTF type for the helper. */
			if (protocol == IPPROTO_TCP &&
			    bpf_core_type_size(struct mptcp_sock))
				msk = bpf_skc_to_mptcp_sock(sk);
			hint = msk ? bpf_sk_storage_get(&socket_cpu, msk, 0, 0) :
				     bpf_sk_storage_get(&socket_cpu, sk, 0, 0);
			if (hint)
				observed = *(volatile __u32 *)&hint->cpu_plus_one;
		}
		bpf_sk_release(sk);
	}
choose:
	if (observed && cpu_allowed(observed - 1)) {
		cpu = observed - 1;
		count(RFS_HINT);
	} else {
		cpu = fallback_cpu(hash);
		count(RFS_FALLBACK);
	}
	if (policy == RFS_POLICY_LLC_LOAD && observed)
		cpu = select_load_cpu(hash, observed - 1, cpu);
	if (policy == RFS_POLICY_LOOKUP)
		cpu = fallback_cpu(hash);
redirect:
	if (hardware && observed && cpu_allowed(observed - 1))
		offer_hardware(&tuple, size, protocol, hardware == 2 ? observed - 1 : cpu);
	/* A lookup miss changes only the candidate, never the ordering domain. */
	if (ordered)
		return bpf_cpumap_redirect(&cpu_map, cpu, hash & (RFS_DOMAINS - 1));
	return bpf_redirect_map(&cpu_map, cpu, XDP_DROP);
pass:
	count(RFS_PASS);
	return XDP_PASS;
drop:
	count(RFS_DROP);
	return XDP_DROP;
}

SEC("xdp.frags")
int rfs_redirect(struct xdp_md *ctx)
{
	return rfs_select(ctx);
}

static int check_domain(__u32 domain, void *ctx)
{
	struct bpf_cpumap_state state = {};
	int err;

	err = bpf_cpumap_get_state(&cpu_map, domain, &state, sizeof(state));
	if (err) {
		query_error = err;
		return 1;
	}
	if (state.pending || (__s64)(state.completed - state.last_tail) < 0)
		busy_domains++;
	return 0;
}

/* Run with BPF_PROG_TEST_RUN only after ingress has been quiesced. */
SEC("xdp.frags")
int rfs_drain(struct xdp_md *ctx)
{
	busy_domains = 0;
	query_error = 0;
	if (ordered)
		bpf_loop(RFS_DOMAINS, check_domain, NULL, 0);
	return XDP_PASS;
}

char LICENSE[] SEC("license") = "GPL";
