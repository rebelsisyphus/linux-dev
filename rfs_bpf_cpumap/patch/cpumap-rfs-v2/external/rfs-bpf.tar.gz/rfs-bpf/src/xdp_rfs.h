/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __XDP_RFS_H
#define __XDP_RFS_H

#define RFS_MAX_CPUS 128
#define RFS_DOMAINS 4096
#define RFS_LOAD_CHOICES 8
#define RFS_LOAD_MAX_AGE_MS 2000
#define RFS_LOAD_HOLD_MS 500
#define RFS_LOAD_MARGIN 100

enum rfs_policy {
	RFS_POLICY_SOCKET,
	RFS_POLICY_HASH,
	RFS_POLICY_LLC_LOAD,
	RFS_POLICY_LOOKUP,
};

struct rfs_load {
	__u32 util; /* EWMA of busy time, 0..1000. */
	__u32 updated_ms;
};

struct rfs_llc {
	__u32 id;
	__u32 count;
	__u32 cpus[RFS_MAX_CPUS];
};

struct rfs_hint {
	/* Zero means unobserved; updates from concurrent users are advisory. */
	__u32 cpu_plus_one;
};

/* Fixed-width shared ABI for the optional RXNFC controller. */
struct rfs_flow_key {
	__u8 saddr[16], daddr[16];
	__be16 sport, dport;
	__u16 family;
	__u8 protocol, reserved;
};

struct rfs_hw_flow {
	struct bpf_spin_lock lock;
	__u32 cpu;
	__u64 seen_ns;
	__u64 generation;
};

struct rfs_hw_config {
	__u32 abi, ifindex, netns_ino, prog_id;
};

enum rfs_stat {
	RFS_HINT,
	RFS_FALLBACK,
	RFS_PASS,
	RFS_DROP,
	RFS_STORAGE_FAILURE,
	RFS_LOAD_SELECTED,
	RFS_HW_FULL,
	RFS_STAT_MAX,
};

#endif
