// SPDX-License-Identifier: GPL-2.0
#define _GNU_SOURCE
#include <errno.h>
#include <glob.h>
#include <limits.h>
#include <net/if.h>
#include <poll.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/random.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#include <linux/if_link.h>
#include <linux/ethtool.h>
#include <linux/netlink.h>
#include <linux/sockios.h>
#include <bpf/bpf.h>
#include <bpf/btf.h>
#include <bpf/libbpf.h>
#include "xdp_rfs.h"
#include "load.h"
#include "xdp_rfs.skel.h"

#define ARRAY_SIZE(array) (sizeof(array) / sizeof((array)[0]))

static volatile sig_atomic_t exiting;

static void on_signal(int sig)
{
	(void)sig;
	exiting = 1;
}

static int interface_up(int fd, const char *name)
{
	struct ifreq req = {};

	snprintf(req.ifr_name, sizeof(req.ifr_name), "%s", name);
	if (ioctl(fd, SIOCGIFFLAGS, &req))
		return -errno;
	return !!(req.ifr_flags & IFF_UP);
}

static bool cpu_online(__u32 cpu)
{
	char *line = NULL, *p, *end;
	unsigned long first, last;
	size_t size = 0;
	bool online = false;
	FILE *file;

	file = fopen("/sys/devices/system/cpu/online", "r");
	if (!file)
		return false;
	if (getline(&line, &size, file) < 0)
		goto out;
	p = line;
	while (*p) {
		first = strtoul(p, &end, 10);
		if (end == p)
			break;
		last = first;
		if (*end == '-') {
			p = end + 1;
			last = strtoul(p, &end, 10);
			if (end == p)
				break;
		}
		if (cpu >= first && cpu <= last) {
			online = true;
			break;
		}
		if (*end != ',')
			break;
		p = end + 1;
	}
out:
	free(line);
	fclose(file);
	return online;
}

static int parse_cpus(struct xdp_rfs *skel, const char *list, int possible)
{
	unsigned long cpu;
	char *end;
	__u32 i, n = 0;

	while (*list) {
		if (n == RFS_MAX_CPUS || *list < '0' || *list > '9')
			return -EINVAL;
		errno = 0;
		cpu = strtoul(list, &end, 10);
		if (errno || cpu >= (unsigned int)possible || (*end && *end != ',') ||
		    !cpu_online(cpu))
			return -EINVAL;
		for (i = 0; i < n; i++) {
			if (skel->rodata->cpus[i] == cpu)
				return -EINVAL;
		}
		skel->rodata->cpus[n++] = cpu;
		if (!*end)
			break;
		list = end + 1;
		if (!*list)
			return -EINVAL;
	}
	skel->rodata->nr_cpus = n;
	return n ? 0 : -EINVAL;
}

static int check_zero_files(const char *pattern)
{
	glob_t paths = {};
	int err, ch;
	size_t i;
	FILE *file;

	err = glob(pattern, 0, NULL, &paths);
	if (err) {
		globfree(&paths);
		return err == GLOB_NOMATCH ? 0 : -EIO;
	}
	for (i = 0; i < paths.gl_pathc; i++) {
		file = fopen(paths.gl_pathv[i], "r");
		if (!file) {
			err = -errno;
			break;
		}
		while ((ch = fgetc(file)) != EOF) {
			if (ch != '0' && ch != ',' && ch != '\n') {
				err = -EBUSY;
				break;
			}
		}
		if (ferror(file))
			err = -EIO;
		fclose(file);
		if (err)
			break;
	}
	globfree(&paths);
	return err;
}

static int open_hotplug(void)
{
	struct sockaddr_nl addr = {
		.nl_family = AF_NETLINK,
		.nl_groups = 1,
	};
	int fd, size = 1024 * 1024;

	fd = socket(AF_NETLINK, SOCK_DGRAM | SOCK_NONBLOCK | SOCK_CLOEXEC,
		    NETLINK_KOBJECT_UEVENT);
	if (fd < 0)
		return -errno;
	/* ENOBUFS is handled by rebuilding every online configured entry. */
	setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &size, sizeof(size));
	if (bind(fd, (void *)&addr, sizeof(addr))) {
		int err = -errno;

		close(fd);
		return err;
	}
	return fd;
}

static bool event_field(const char *buf, size_t len, const char *field)
{
	size_t n;

	while (len) {
		n = strnlen(buf, len);
		if (n == len)
			break;
		if (!strcmp(buf, field))
			return true;
		buf += n + 1;
		len -= n + 1;
	}
	return false;
}

/* A complete offline/online cycle between polls still recreates the worker. */
static int hotplug_events(int fd, struct xdp_rfs *skel, bool *recreate)
{
	struct sockaddr_nl addr;
	char buf[8192], path[128];
	socklen_t addrlen;
	ssize_t len;
	__u32 i;

	for (;;) {
		addrlen = sizeof(addr);
		len = recvfrom(fd, buf, sizeof(buf), MSG_TRUNC, (void *)&addr, &addrlen);
		if (len < 0) {
			if (errno == EAGAIN)
				return 0;
			if (errno == EINTR)
				continue;
			if (errno != ENOBUFS)
				return -errno;
		}
		if (len < 0 || len >= (ssize_t)sizeof(buf)) {
			for (i = 0; i < skel->rodata->nr_cpus; i++)
				recreate[i] = true;
			continue;
		}
		if (addr.nl_pid || !event_field(buf, len, "SUBSYSTEM=cpu") ||
		    (!event_field(buf, len, "ACTION=online") &&
		     !event_field(buf, len, "ACTION=offline")))
			continue;
		for (i = 0; i < skel->rodata->nr_cpus; i++) {
			snprintf(path, sizeof(path), "DEVPATH=/devices/system/cpu/cpu%u",
				 skel->rodata->cpus[i]);
			if (event_field(buf, len, path))
				recreate[i] = true;
		}
	}
}

static int refresh_cpus(struct xdp_rfs *skel, bool *active, bool *recreate)
{
	struct bpf_cpumap_val entry = { .qsize = 2048 };
	int map = bpf_map__fd(skel->maps.cpu_map);
	int allow = bpf_map__fd(skel->maps.allowed);
	__u32 i, cpu, zero = 0, one = 1;
	bool online;

	for (i = 0; i < skel->rodata->nr_cpus; i++) {
		cpu = skel->rodata->cpus[i];
		online = cpu_online(cpu);
		if (active[i] && (!online || recreate[i])) {
			/* Withdraw eligibility before retiring this entry generation. */
			if (bpf_map_update_elem(allow, &cpu, &zero, BPF_ANY))
				return -errno;
			if (bpf_map_delete_elem(map, &cpu) && errno != ENOENT)
				return -errno;
			active[i] = false;
			printf("cpu %u withdrawn\n", cpu);
		}
		recreate[i] = false;
		if (!online || active[i])
			continue;
		if (bpf_map_update_elem(map, &cpu, &entry, BPF_ANY)) {
			fprintf(stderr, "cpu %u queue creation failed: %s; retrying\n",
				cpu, strerror(errno));
			continue;
		}
		if (bpf_map_update_elem(allow, &cpu, &one, BPF_ANY))
			return -errno;
		active[i] = true;
		printf("cpu %u online: queue recreated\n", cpu);
	}
	fflush(stdout);
	return 0;
}

static int check_native_rps(const char *name)
{
	static const char * const attributes[] = { "rps_cpus", "rps_flow_cnt" };
	char escaped[2 * IFNAMSIZ], *dst = escaped;
	char pattern[PATH_MAX];
	int err;
	size_t i;

	/* Valid interface names can contain glob metacharacters. */
	for (; *name; name++) {
		if (strchr("\\*?[]", *name))
			*dst++ = '\\';
		*dst++ = *name;
	}
	*dst = '\0';
	/* RFS can steer with a flow table even when rps_cpus is empty. */
	for (i = 0; i < ARRAY_SIZE(attributes); i++) {
		snprintf(pattern, sizeof(pattern), "/sys/class/net/%s/queues/rx-*/%s",
			 escaped, attributes[i]);
		err = check_zero_files(pattern);
		if (err)
			return err;
	}
	return 0;
}

/* Native redirect cannot restore a VLAN tag stripped before the XDP hook. */
static int check_vlan_strip(int fd, const char *name)
{
	struct {
		struct ethtool_sset_info hdr;
		__u32 count;
	} info = { .hdr.cmd = ETHTOOL_GSSET_INFO,
		   .hdr.sset_mask = 1ULL << ETH_SS_FEATURES };
	struct ethtool_gfeatures *features = NULL;
	struct ethtool_gstrings *names = NULL;
	struct ifreq req = {};
	unsigned int i, blocks;
	int err = -EOPNOTSUPP;

	snprintf(req.ifr_name, sizeof(req.ifr_name), "%s", name);
	req.ifr_data = (void *)&info;
	if (ioctl(fd, SIOCETHTOOL, &req))
		return -errno;
	if (!(info.hdr.sset_mask & (1ULL << ETH_SS_FEATURES)) ||
	    !info.count || info.count > 65536)
		return -EOPNOTSUPP;
	blocks = (info.count + 31) / 32;
	names = calloc(1, sizeof(*names) + info.count * ETH_GSTRING_LEN);
	features = calloc(1, sizeof(*features) + blocks * sizeof(features->features[0]));
	if (!names || !features) {
		err = -ENOMEM;
		goto out;
	}
	names->cmd = ETHTOOL_GSTRINGS;
	names->string_set = ETH_SS_FEATURES;
	names->len = info.count;
	req.ifr_data = (void *)names;
	if (ioctl(fd, SIOCETHTOOL, &req)) {
		err = -errno;
		goto out;
	}
	features->cmd = ETHTOOL_GFEATURES;
	features->size = blocks;
	req.ifr_data = (void *)features;
	if (ioctl(fd, SIOCETHTOOL, &req)) {
		err = -errno;
		goto out;
	}
	err = 0;
	for (i = 0; i < info.count; i++) {
		const char *feature = (char *)&names->data[i * ETH_GSTRING_LEN];

		if (strncmp(feature, "rx-vlan-hw-parse", ETH_GSTRING_LEN) &&
		    strncmp(feature, "rx-vlan-stag-hw-parse", ETH_GSTRING_LEN))
			continue;
		if (features->features[i / 32].active & (1U << (i % 32))) {
			fprintf(stderr, "Disable %.*s before native XDP redirect\n",
				ETH_GSTRING_LEN, feature);
			err = -EBUSY;
			break;
		}
	}
out:
	free(features);
	free(names);
	return err;
}

static int drain(struct xdp_rfs *skel)
{
	char packet[14] = {};

	LIBBPF_OPTS(bpf_test_run_opts, opts,
		    .data_in = packet,
		    .data_size_in = sizeof(packet),
	);
	struct timespec start, now;
	int err;

	clock_gettime(CLOCK_MONOTONIC, &start);
	do {
		err = bpf_prog_test_run_opts(bpf_program__fd(skel->progs.rfs_drain), &opts);
		if (err)
			return err;
		if (skel->bss->query_error)
			return skel->bss->query_error;
		if (!skel->bss->busy_domains)
			return 0;
		usleep(10000);
		clock_gettime(CLOCK_MONOTONIC, &now);
	} while (now.tv_sec - start.tv_sec < 10);
	return -ETIMEDOUT;
}

static void print_stats(struct xdp_rfs *skel, int possible)
{
	static const char * const names[] = {
		"hint", "fallback", "pass", "drop", "storage_failure", "load_selected",
		"hardware_hint_failure",
	};
	__u64 *values = calloc(possible, sizeof(*values)), total;
	__u32 key;
	int cpu;

	if (!values)
		return;
	for (key = 0; key < RFS_STAT_MAX; key++) {
		if (bpf_map_lookup_elem(bpf_map__fd(skel->maps.stats), &key, values))
			break;
		total = 0;
		for (cpu = 0; cpu < possible; cpu++)
			total += values[cpu];
		printf("%s=%llu%c", names[key], (unsigned long long)total,
		       key == RFS_STAT_MAX - 1 ? '\n' : ' ');
	}
	free(values);
}

static void usage(const char *prog)
{
	fprintf(stderr, "Usage: %s [-SU] [-p rfs|hash|llc-load|lookup] [-s SEED]\n"
		"       [-H PIN_DIR] [-N] -i IFNAME -c CPU,CPU,...\n"
		"  -S: generic XDP (default: driver XDP)\n"
		"  -U: unordered CPUMAP for baseline measurements; no migration barrier\n"
		"  -p lookup: perform lookup/storage, but keep hash placement (measurement)\n"
		"  -s: fixed 32-bit hash seed for reproducible comparisons (default: random)\n"
		"  -H: export hardware intents to a new private directory in bpffs\n"
		"  -N: hardware intents follow socket CPU instead of policy CPU\n"
		"Keep the interface down during startup and shutdown.\n"
		"Bring it up after 'ready'; bring it down before Ctrl-C.\n"
		"The CPU set is fixed; hotplug within it is tracked automatically.\n"
		"Disable native RPS and RFS on the interface.\n",
		prog);
}

static int pin_hardware(struct xdp_rfs *skel, const char *dir, int ifindex, __u32 netns)
{
	struct rfs_hw_config cfg = { .abi = 1, .ifindex = ifindex, .netns_ino = netns };
	struct bpf_prog_info info = {};
	__u32 size = sizeof(info), zero = 0;
	char path[PATH_MAX];

	if (bpf_prog_get_info_by_fd(bpf_program__fd(skel->progs.rfs_redirect), &info, &size))
		return -errno;
	cfg.prog_id = info.id;
	if (bpf_map_update_elem(bpf_map__fd(skel->maps.hw_config), &zero, &cfg, BPF_ANY) ||
	    bpf_map_freeze(bpf_map__fd(skel->maps.hw_config)))
		return -errno;
	snprintf(path, sizeof(path), "%s/flows", dir);
	if (bpf_map__pin(skel->maps.hw_flows, path))
		return -errno;
	snprintf(path, sizeof(path), "%s/allowed", dir);
	if (bpf_map__pin(skel->maps.allowed, path))
		return -errno;
	snprintf(path, sizeof(path), "%s/config", dir);
	return bpf_map__pin(skel->maps.hw_config, path);
}

static void unpin_hardware(const char *dir)
{
	static const char * const names[] = { "flows", "allowed", "config" };
	char path[PATH_MAX];
	unsigned int i;

	for (i = 0; i < ARRAY_SIZE(names); i++) {
		snprintf(path, sizeof(path), "%s/%s", dir, names[i]);
		unlink(path);
	}
	rmdir(dir);
}

int main(int argc, char **argv)
{
	const char *name = NULL, *cpu_list = NULL, *pin_dir = NULL;
	__u32 flags = XDP_FLAGS_DRV_MODE;
	struct xdp_rfs *skel = NULL;
	struct bpf_program *prog;
	struct btf *btf = NULL;
	struct rfs_cpu_sample *samples = NULL;
	struct stat ns;
	bool attached = false, warned = false, pin_created = false, socket_hardware = false;
	bool ordered = true;
	bool seed_set = false;
	bool active[RFS_MAX_CPUS] = {}, recreate[RFS_MAX_CPUS] = {};
	int opt, possible, ifindex, fd = -1, hotplug_fd = -1, err = 1;
	__u32 i;
	__u32 policy = RFS_POLICY_SOCKET;
	__u32 seed = 0;

	while ((opt = getopt(argc, argv, "SUNi:c:p:s:H:h")) != -1) {
		switch (opt) {
		case 'S':
			flags = XDP_FLAGS_SKB_MODE;
			break;
		case 'U':
			ordered = false;
			break;
		case 'i':
			name = optarg;
			break;
		case 'c':
			cpu_list = optarg;
			break;
		case 'H':
			pin_dir = optarg;
			break;
		case 'N':
			socket_hardware = true;
			break;
		case 's': {
			char *end;
			unsigned long value;

			errno = 0;
			value = strtoul(optarg, &end, 0);
			if (errno || !*optarg || *end || *optarg == '-' || value > UINT32_MAX) {
				fprintf(stderr, "Invalid 32-bit hash seed\n");
				return 1;
			}
			seed = value;
			seed_set = true;
			break;
		}
		case 'p':
			if (!strcmp(optarg, "rfs")) {
				policy = RFS_POLICY_SOCKET;
			} else if (!strcmp(optarg, "hash")) {
				policy = RFS_POLICY_HASH;
			} else if (!strcmp(optarg, "llc-load")) {
				policy = RFS_POLICY_LLC_LOAD;
			} else if (!strcmp(optarg, "lookup")) {
				policy = RFS_POLICY_LOOKUP;
			} else {
				usage(argv[0]);
				return 1;
			}
			break;
		default:
			usage(argv[0]);
			return opt == 'h' ? 0 : 1;
		}
	}
	if (!name || !cpu_list || optind != argc || strlen(name) >= IFNAMSIZ) {
		usage(argv[0]);
		return 1;
	}
	if ((socket_hardware && !pin_dir) ||
	    (pin_dir && (strlen(pin_dir) >= PATH_MAX - 16 || !ordered ||
			(policy != RFS_POLICY_SOCKET && policy != RFS_POLICY_LLC_LOAD)))) {
		fprintf(stderr, "Hardware intents require rfs/llc-load "
			"and a short pin directory\n");
		return 1;
	}
	fd = socket(AF_INET, SOCK_DGRAM | SOCK_CLOEXEC, 0);
	ifindex = if_nametoindex(name);
	if (fd < 0 || !ifindex || interface_up(fd, name) != 0) {
		fprintf(stderr, "Interface must exist and be administratively down\n");
		goto out;
	}
	if (check_native_rps(name)) {
		fprintf(stderr, "Cannot verify that all RX queues have native RPS/RFS disabled\n");
		goto out;
	}
	if (flags == XDP_FLAGS_DRV_MODE && check_vlan_strip(fd, name)) {
		fprintf(stderr, "Cannot verify RX VLAN stripping is disabled\n");
		goto out;
	}
	/* Subscribe before the first topology snapshot to close the startup gap. */
	hotplug_fd = open_hotplug();
	if (hotplug_fd < 0) {
		fprintf(stderr, "Cannot monitor CPU hotplug: %s\n", strerror(-hotplug_fd));
		goto out;
	}
	possible = libbpf_num_possible_cpus();
	if (possible <= 0 || stat("/proc/self/ns/net", &ns))
		goto out;
	skel = xdp_rfs__open();
	if (!skel)
		goto out;
	if (parse_cpus(skel, cpu_list, possible)) {
		fprintf(stderr, "CPU list must contain distinct online CPUs (at most %d)\n",
			RFS_MAX_CPUS);
		goto out;
	}
	skel->rodata->netns_ino = ns.st_ino;
	skel->rodata->policy = policy;
	skel->rodata->ordered = ordered;
	skel->rodata->hardware = pin_dir ? (socket_hardware ? 2 : 1) : 0;
	if (!seed_set && getrandom(&seed, sizeof(seed), 0) != sizeof(seed))
		goto out;
	skel->rodata->hash_seed = seed;
	if (bpf_map__set_max_entries(skel->maps.cpu_map, possible) ||
	    bpf_map__set_max_entries(skel->maps.allowed, possible) ||
	    bpf_map__set_max_entries(skel->maps.cpu_load, possible) ||
	    bpf_map__set_max_entries(skel->maps.llc, possible) ||
	    bpf_map__set_map_extra(skel->maps.cpu_map, ordered ? RFS_DOMAINS : 0) ||
	    bpf_map__set_max_entries(skel->maps.hw_flows, pin_dir ? 1024 : 1))
		goto out;
	btf = btf__load_vmlinux_btf();
	if (libbpf_get_error(btf)) {
		btf = NULL;
		goto out;
	}
	if (btf__find_by_name_kind(btf, "tcp_zerocopy_receive", BTF_KIND_FUNC) < 0) {
		bpf_program__set_autoload(skel->progs.rfs_zerocopy, false);
		fprintf(stderr, "tcp_zerocopy_receive unavailable: observer disabled\n");
	}
	if (btf__find_by_name_kind(btf, "io_zcrx_recv", BTF_KIND_FUNC) < 0) {
		bpf_program__set_autoload(skel->progs.rfs_zcrx, false);
		fprintf(stderr, "io_zcrx_recv unavailable: observer disabled\n");
	}
	if (btf__find_by_name_kind(btf, "mptcp_stream_accept", BTF_KIND_FUNC) < 0) {
		bpf_program__set_autoload(skel->progs.rfs_mptcp_accept, false);
		bpf_program__set_autoload(skel->progs.rfs_mptcp_splice, false);
		fprintf(stderr, "MPTCP unavailable: protocol observers disabled\n");
	}
	if (btf__find_by_name_kind(btf, "inet6_recvmsg", BTF_KIND_FUNC) < 0) {
		bpf_program__set_autoload(skel->progs.rfs_recv6, false);
		bpf_program__set_autoload(skel->progs.rfs_send6, false);
		fprintf(stderr, "inet6_recvmsg unavailable: IPv6 observer disabled\n");
	}
	if (policy == RFS_POLICY_HASH) {
		bpf_object__for_each_program(prog, skel->obj) {
			if (bpf_program__type(prog) == BPF_PROG_TYPE_TRACING)
				bpf_program__set_autoload(prog, false);
		}
	}
	if (xdp_rfs__load(skel))
		goto out;
	if (pin_dir) {
		if (mkdir(pin_dir, 0700)) {
			perror("create private hardware map directory");
			goto out;
		}
		pin_created = true;
		if (pin_hardware(skel, pin_dir, ifindex, ns.st_ino)) {
			fprintf(stderr, "Cannot pin hardware maps in bpffs\n");
			goto out;
		}
	}
	if (policy == RFS_POLICY_LLC_LOAD) {
		samples = calloc(possible, sizeof(*samples));
		if (!samples || rfs_init_topology(bpf_map__fd(skel->maps.llc), possible,
						  skel->rodata->cpus, skel->rodata->nr_cpus)) {
			fprintf(stderr, "Cannot initialize LLC topology\n");
			goto out;
		}
	}
	/* Only tracing programs auto-attach; ingress and drain are explicit. */
	bpf_object__for_each_program(prog, skel->obj) {
		if (bpf_program__type(prog) == BPF_PROG_TYPE_XDP)
			bpf_program__set_autoattach(prog, false);
	}
	if (xdp_rfs__attach(skel))
		goto out;
	if (refresh_cpus(skel, active, recreate))
		goto out;
	for (i = 0; i < skel->rodata->nr_cpus; i++) {
		if (!active[i]) {
			fprintf(stderr, "Initial CPU queue unavailable; ingress not attached\n");
			goto out;
		}
	}
	signal(SIGINT, on_signal);
	signal(SIGTERM, on_signal);
	if (bpf_xdp_attach(ifindex, bpf_program__fd(skel->progs.rfs_redirect),
			   flags | XDP_FLAGS_UPDATE_IF_NOEXIST, NULL))
		goto out;
	attached = true;
	if (!ordered)
		fprintf(stderr, "Measurement baseline: ordinary CPUMAP, "
			"no ordering/drain guarantee\n");
	printf("ready on %s; bring ingress up. Down the interface before Ctrl-C.\n", name);
	fflush(stdout);
	for (;;) {
		struct pollfd event = { .fd = hotplug_fd, .events = POLLIN };
		int up = interface_up(fd, name);

		if (exiting && !up)
			break;
		if (exiting && !warned) {
			fprintf(stderr, "Waiting for interface down; policy remains attached\n");
			warned = true;
		}
		if (up < 0) {
			fprintf(stderr, "Cannot inspect interface: %s\n", strerror(-up));
			goto out;
		}
		if (hotplug_events(hotplug_fd, skel, recreate) ||
		    refresh_cpus(skel, active, recreate)) {
			fprintf(stderr, "CPU topology reconciliation failed\n");
			goto out;
		}
		if (samples && rfs_sample_load(bpf_map__fd(skel->maps.cpu_load), possible, samples))
			fprintf(stderr, "Load telemetry unavailable; stale samples expire\n");
		if (poll(&event, 1, samples ? 250 : 1000) < 0 && errno != EINTR)
			goto out;
	}
	if (drain(skel)) {
		fprintf(stderr, "Drain failed; leaving XDP attached\n");
		goto out;
	}
	{
		LIBBPF_OPTS(bpf_xdp_attach_opts, opts,
			    .old_prog_fd = bpf_program__fd(skel->progs.rfs_redirect),
		);

		if (bpf_xdp_detach(ifindex, flags, &opts))
			goto out;
	}
	attached = false;
	print_stats(skel, possible);
	err = 0;
out:
	if (attached)
		fprintf(stderr, "XDP/map retained; quiesce ingress before manual recovery\n");
	if (pin_created && !attached)
		unpin_hardware(pin_dir);
	btf__free(btf);
	xdp_rfs__destroy(skel);
	free(samples);
	if (hotplug_fd >= 0)
		close(hotplug_fd);
	if (fd >= 0)
		close(fd);
	return err;
}
