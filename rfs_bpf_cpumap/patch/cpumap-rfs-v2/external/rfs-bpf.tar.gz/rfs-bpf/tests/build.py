#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0
"""Build the external policy's regression suite in the kernel test_progs runner."""
import argparse
import os
from pathlib import Path
import subprocess
import shutil

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--kernel-src', required=True, type=Path)
parser.add_argument('--vmlinux', required=True, type=Path)
parser.add_argument('--output', required=True, type=Path)
args = parser.parse_args()
repo = Path(__file__).resolve().parent.parent
kernel = args.kernel_src.resolve()
out = args.output.resolve()
tests = kernel / 'tools/testing/selftests/bpf'
out.mkdir(parents=True, exist_ok=True)
btf_image = out / 'kernel-btf-image'
source_image = args.vmlinux.resolve()
if not btf_image.exists() or btf_image.stat().st_mtime_ns != source_image.stat().st_mtime_ns:
    shutil.copy2(source_image, btf_image)
makefile = out / 'Makefile'
source = (tests / 'Makefile').read_text()
source = source.replace('TRUNNER_TESTS_DIR := prog_tests',
                        'TRUNNER_TESTS_DIR := ' + os.path.relpath(repo / 'tests/prog_tests', tests))
source = source.replace('TRUNNER_BPF_PROGS_DIR := progs',
                        'TRUNNER_BPF_PROGS_DIR := ' + os.path.relpath(repo / 'tests/progs', tests))
source += '\n$(OUTPUT)/test_external_xdp_rfs.bpf.o: ' + str(repo / 'src/xdp_rfs.bpf.c') + ' ' + str(repo / 'src/xdp_rfs.h') + '\n'
makefile.write_text(source)
env = os.environ.copy()
env['CFLAGS'] = ('-I' + str(repo / 'src') + ' -I' + str(repo / 'tests') +
                 ' -I' + str(repo / 'tests/progs'))
prog = os.path.relpath(repo / 'tests/progs/test_external_xdp_rfs.c', tests)
command = ['make', '-C', str(tests), '-f', str(makefile), 'OUTPUT=' + str(out) + '/',
           'VMLINUX_BTF=' + str(btf_image),
           'LSKELS=', 'LSKELS_EXTRA=', 'LSKELS_SIGNED=', 'LINKED_SKELS=',
           'LIBARENA_SKEL=', 'LIBARENA_ASAN_SKEL=', 'TRUNNER_EXTRA_FILES=ima_setup.sh',
           'SKIP_DOCS=1', 'SKIP_LLVM=1', 'SKIP_LIBBFD=1', 'BPF_STRICT_BUILD=1',
           prog + '-CFLAGS=-I' + str(repo / 'src'),
           'LLVM_STRIP=llvm-strip-18', 'LLVM_OBJCOPY=llvm-objcopy-18', '-j8', 'test_progs']
with (out / 'build.log').open('w') as log:
    result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT)
print('\n'.join((out / 'build.log').read_text().splitlines()[-40:]))
raise SystemExit(result.returncode)
