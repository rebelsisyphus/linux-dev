// SPDX-License-Identifier: GPL-2.0
#define _GNU_SOURCE
#include <sched.h>
#include <net/if.h>
#include <sys/stat.h>
#include <linux/mptcp.h>
#include <time.h>
#include <linux/if_link.h>
#include <bpf/btf.h>
#include <test_progs.h>
#include <network_helpers.h>
#include "xdp_rfs.h"
#include "test_external_xdp_rfs.h"
#include "test_external_xdp_rfs.skel.h"

static int test_protocol;
static __u32 test_policy_kind;
static __u32 test_hardware;
static bool test_ordered = true;

struct rfs_fixture {
	struct test_external_xdp_rfs *skel;
	struct nstoken *ns;
	struct bpf_tc_hook tc;
	cpu_set_t affinity;
	char name[64];
	int cpus[3], ifindex, listener, server, client;
	bool attached, affinity_saved;
};

static int pin_cpu(int cpu)
{
	cpu_set_t set;

	CPU_ZERO(&set);
	CPU_SET(cpu, &set);
	return sched_setaffinity(0, sizeof(set), &set);
}

static bool drain(struct rfs_fixture *f)
{
	char packet[14] = {};

	LIBBPF_OPTS(bpf_test_run_opts, opts,
		    .data_in = packet,
		    .data_size_in = sizeof(packet),
	);
	int i, err;

	for (i = 0; i < 1000; i++) {
		err = bpf_prog_test_run_opts(bpf_program__fd(f->skel->progs.rfs_drain), &opts);
		if (err || f->skel->bss->query_error)
			return false;
		if (!f->skel->bss->busy_domains)
			return true;
		usleep(1000);
	}
	return false;
}

static bool hint_is(struct rfs_fixture *f, int cpu)
{
	struct rfs_hint hint;
	int err;

	err = bpf_map_lookup_elem(bpf_map__fd(f->skel->maps.socket_cpu), &f->server, &hint);
	return ASSERT_OK(err, "read_socket_hint") &&
	       ASSERT_EQ(hint.cpu_plus_one, cpu + 1, "socket_cpu");
}

static __u64 stat_sum(struct rfs_fixture *f, __u32 key)
{
	int possible = libbpf_num_possible_cpus(), cpu;
	__u64 *values, total = 0;

	values = calloc(possible, sizeof(*values));
	if (!ASSERT_OK_PTR(values, "stat_alloc"))
		return 0;
	if (ASSERT_OK(bpf_map_lookup_elem(bpf_map__fd(f->skel->maps.stats), &key, values),
		      "read_stats")) {
		for (cpu = 0; cpu < possible; cpu++)
			total += values[cpu];
	}
	free(values);
	return total;
}

/* Wait for TC before recv(), so recv's new hint cannot decide this packet. */
static bool transmit(struct rfs_fixture *f, int expected_cpu, char value)
{
	__u32 before = __atomic_load_n(&f->skel->bss->packets, __ATOMIC_RELAXED);
	int i;

	if (!ASSERT_OK(pin_cpu(f->cpus[0]), "pin_sender") ||
	    !ASSERT_EQ(send(f->client, &value, 1, 0), 1, "send"))
		return false;
	for (i = 0; i < 5000; i++) {
		if (__atomic_load_n(&f->skel->bss->packets, __ATOMIC_RELAXED) > before)
			break;
		usleep(1000);
	}
	if (!ASSERT_LT(i, 5000, "stack_handoff") || !ASSERT_TRUE(drain(f), "drain"))
		return false;
	if (expected_cpu >= 0)
		return ASSERT_EQ(f->skel->bss->receive_cpu, expected_cpu, "receive_cpu");
	return true;
}

static bool consume(struct rfs_fixture *f, int cpu, char expected)
{
	char value = 0;

	return ASSERT_OK(pin_cpu(cpu), "pin_reader") &&
	       ASSERT_EQ(recv(f->server, &value, 1, 0), 1, "recv") &&
	       ASSERT_EQ(value, expected, "payload_order") && hint_is(f, cpu);
}

static void cleanup(struct rfs_fixture *f)
{
	if (f->client >= 0)
		close(f->client);
	if (f->server >= 0)
		close(f->server);
	if (f->listener >= 0)
		close(f->listener);
	if (f->attached) {
		/* Closing TCP emits FINs; stop ingress before checking all domains. */
		SYS_NOFAIL("ip link set lo down");
		ASSERT_TRUE(drain(f), "cleanup_drain");
		bpf_xdp_detach(f->ifindex, XDP_FLAGS_SKB_MODE, NULL);
	}
	if (f->tc.ifindex)
		bpf_tc_hook_destroy(&f->tc);
	test_external_xdp_rfs__destroy(f->skel);
	close_netns(f->ns);
	if (f->name[0])
		SYS_NOFAIL("ip netns del %s", f->name);
	if (f->affinity_saved)
		sched_setaffinity(0, sizeof(f->affinity), &f->affinity);
}

static bool setup(struct rfs_fixture *f, int family, int type)
{
	struct bpf_cpumap_val entry = { .qsize = 2048 };
	struct network_helper_opts socket_opts = { .timeout_ms = 3000, .proto = test_protocol };
	struct sockaddr_storage addr;
	socklen_t len = sizeof(addr);
	struct bpf_program *prog;
	struct btf *btf;
	struct stat ns;
	int cpu, n = 0, possible, i, err;
	__u32 key, one = 1;

	LIBBPF_OPTS(bpf_tc_opts, tc_opts, .handle = 1, .priority = 1);

	memset(f, 0, sizeof(*f));
	f->listener = -1;
	f->server = -1;
	f->client = -1;
	if (!ASSERT_OK(sched_getaffinity(0, sizeof(f->affinity), &f->affinity), "affinity"))
		return false;
	f->affinity_saved = true;
	for (cpu = 0; cpu < CPU_SETSIZE && n < 3; cpu++) {
		if (CPU_ISSET(cpu, &f->affinity))
			f->cpus[n++] = cpu;
	}
	if (n < 3) {
		test__skip();
		return false;
	}
	snprintf(f->name, sizeof(f->name), "xdp_rfs_%d", getpid());
	SYS(fail, "ip netns add %s", f->name);
	f->ns = open_netns(f->name);
	if (!ASSERT_OK_PTR(f->ns, "netns") ||
	    !ASSERT_OK(stat("/proc/self/ns/net", &ns), "netns_inode"))
		goto fail;
	SYS(fail, "ip link set lo up");
	f->ifindex = if_nametoindex("lo");
	f->skel = test_external_xdp_rfs__open();
	if (!ASSERT_OK_PTR(f->skel, "open"))
		goto fail;
	possible = libbpf_num_possible_cpus();
	if (!ASSERT_GT(possible, 0, "possible_cpus"))
		goto fail;
	bpf_map__set_max_entries(f->skel->maps.cpu_map, possible);
	bpf_map__set_max_entries(f->skel->maps.allowed, possible);
	bpf_map__set_max_entries(f->skel->maps.cpu_load, possible);
	bpf_map__set_max_entries(f->skel->maps.llc, possible);
	f->skel->rodata->policy = test_policy_kind;
	f->skel->rodata->ordered = test_ordered;
	bpf_map__set_map_extra(f->skel->maps.cpu_map, test_ordered ? RFS_DOMAINS : 0);
	f->skel->rodata->hardware = test_hardware;
	if (test_hardware)
		bpf_map__set_max_entries(f->skel->maps.hw_flows, 1);
	f->skel->rodata->nr_cpus = 2;
	f->skel->rodata->cpus[0] = f->cpus[1];
	f->skel->rodata->cpus[1] = f->cpus[2];
	f->skel->rodata->netns_ino = ns.st_ino;
	f->skel->rodata->hash_seed = 0x12345678;
	btf = btf__load_vmlinux_btf();
	if (!ASSERT_OK_PTR(btf, "kernel_btf"))
		goto fail;
	if (btf__find_by_name_kind(btf, "io_zcrx_recv", BTF_KIND_FUNC) < 0)
		bpf_program__set_autoload(f->skel->progs.rfs_zcrx, false);
	if (btf__find_by_name_kind(btf, "mptcp_stream_accept", BTF_KIND_FUNC) < 0) {
		bpf_program__set_autoload(f->skel->progs.rfs_mptcp_accept, false);
		bpf_program__set_autoload(f->skel->progs.rfs_mptcp_splice, false);
	}
	btf__free(btf);
	if (!ASSERT_OK(test_external_xdp_rfs__load(f->skel), "load"))
		goto fail;
	bpf_object__for_each_program(prog, f->skel->obj) {
		if (bpf_program__type(prog) != BPF_PROG_TYPE_TRACING)
			bpf_program__set_autoattach(prog, false);
	}
	if (!ASSERT_OK(test_external_xdp_rfs__attach(f->skel), "attach_observers"))
		goto fail;
	for (i = 1; i < 3; i++) {
		key = f->cpus[i];
		if (!ASSERT_OK(bpf_map_update_elem(bpf_map__fd(f->skel->maps.cpu_map),
						   &key, &entry, BPF_ANY), "create_cpu") ||
		    !ASSERT_OK(bpf_map_update_elem(bpf_map__fd(f->skel->maps.allowed),
						   &key, &one, BPF_ANY), "allow_cpu"))
			goto fail;
	}
	f->tc.sz = sizeof(f->tc);
	f->tc.ifindex = f->ifindex;
	f->tc.attach_point = BPF_TC_INGRESS;
	if (!ASSERT_OK(bpf_tc_hook_create(&f->tc), "tc_create"))
		goto fail;
	tc_opts.prog_fd = bpf_program__fd(f->skel->progs.rfs_receive);
	if (!ASSERT_OK(bpf_tc_attach(&f->tc, &tc_opts), "tc_attach"))
		goto fail;
	err = bpf_xdp_attach(f->ifindex, bpf_program__fd(f->skel->progs.rfs_redirect),
			     XDP_FLAGS_SKB_MODE | XDP_FLAGS_UPDATE_IF_NOEXIST, NULL);
	if (!ASSERT_OK(err, "xdp_attach"))
		goto fail;
	f->attached = true;
	if (!ASSERT_OK(pin_cpu(f->cpus[0]), "pin_setup"))
		goto fail;
	f->listener = start_server_str(family, type, family == AF_INET ? "127.0.0.1" : "::1",
				       0, &socket_opts);
	if (!ASSERT_OK_FD(f->listener, "listener"))
		goto fail;
	if (!ASSERT_OK(getsockname(f->listener, (void *)&addr, &len), "getsockname"))
		goto fail;
	f->skel->bss->server_port = family == AF_INET ?
		((struct sockaddr_in *)&addr)->sin_port : ((struct sockaddr_in6 *)&addr)->sin6_port;
	f->client = connect_to_fd_opts(f->listener, &socket_opts);
	if (!ASSERT_OK_FD(f->client, "connect"))
		goto fail;
	if (type == SOCK_STREAM) {
		if (!ASSERT_OK(pin_cpu(f->cpus[1]), "pin_accept"))
			goto fail;
		f->server = accept(f->listener, NULL, NULL);
		if (!ASSERT_OK_FD(f->server, "accept") || !hint_is(f, f->cpus[1]))
			goto fail;
	} else {
		f->server = f->listener;
		f->listener = -1;
		if (!ASSERT_OK(connect_fd_to_fd(f->server, f->client, 3000), "connect_udp"))
			goto fail;
	}
	return ASSERT_TRUE(drain(f), "setup_drain");
fail:
	return false;
}

static void test_policy(int family, int type)
{
	struct rfs_fixture f;
	struct rfs_hint hint;
	struct sockaddr_storage addr;
	socklen_t addrlen = sizeof(addr);
	__u64 fallback, hits;
	int err, fallback_cpu, pipefd[2] = { -1, -1 };
	char value;

	if (!setup(&f, family, type))
		goto out;
	/* Accept already supplies a hint; connected UDP starts without one. */
	if (!transmit(&f, type == SOCK_STREAM ? f.cpus[1] : -1, 'a') ||
	    !consume(&f, f.cpus[2], 'a'))
		goto out;
	hits = stat_sum(&f, RFS_HINT);
	if (!transmit(&f, f.cpus[2], 'b') || !consume(&f, f.cpus[1], 'b') ||
	    !ASSERT_GT(stat_sum(&f, RFS_HINT), hits, "used_socket_hint"))
		goto out;
	if (!transmit(&f, f.cpus[1], 'c') || !consume(&f, f.cpus[2], 'c'))
		goto out;

	/* Error-queue reads must not update the application CPU hint. */
	if (!ASSERT_OK(pin_cpu(f.cpus[0]), "pin_error_reader"))
		goto out;
	recv(f.server, &value, 1, MSG_ERRQUEUE | MSG_DONTWAIT);
	if (!hint_is(&f, f.cpus[2]))
		goto out;

	/* A CPU outside the configured set changes only the candidate CPU. */
	recv(f.server, &value, 1, MSG_DONTWAIT);
	if (!hint_is(&f, f.cpus[0]))
		goto out;
	fallback = stat_sum(&f, RFS_FALLBACK);
	if (!transmit(&f, -1, 'd'))
		goto out;
	fallback_cpu = f.skel->bss->receive_cpu;
	if (!ASSERT_TRUE(fallback_cpu == f.cpus[1] || fallback_cpu == f.cpus[2],
			 "fallback_in_cpu_set") ||
	    !ASSERT_GT(stat_sum(&f, RFS_FALLBACK), fallback, "outside_cpu_fallback") ||
	    !consume(&f, f.cpus[2], 'd'))
		goto out;

	/* Missing storage does not pass locally or create storage from XDP. */
	if (!ASSERT_OK(bpf_map_delete_elem(bpf_map__fd(f.skel->maps.socket_cpu), &f.server),
		       "delete_hint") || !transmit(&f, fallback_cpu, 'e'))
		goto out;
	err = bpf_map_lookup_elem(bpf_map__fd(f.skel->maps.socket_cpu), &f.server, &hint);
	if (!ASSERT_ERR(err, "xdp_did_not_create_hint") ||
	    !consume(&f, f.cpus[1], 'e'))
		goto out;

	/* Send-side use independently updates the receiver's socket hint. */
	if (!ASSERT_OK(pin_cpu(f.cpus[2]), "pin_server_send") ||
	    !ASSERT_EQ(send(f.server, "f", 1, 0), 1, "server_send") ||
	    !hint_is(&f, f.cpus[2]) ||
	    !ASSERT_EQ(recv(f.client, &value, 1, 0), 1, "client_recv") ||
	    !ASSERT_TRUE(drain(&f), "reply_drain") ||
	    !transmit(&f, f.cpus[2], 'g'))
		goto out;
	if (type == SOCK_STREAM) {
		if (!ASSERT_OK(pipe(pipefd), "pipe") ||
		    !ASSERT_OK(pin_cpu(f.cpus[1]), "pin_splice") ||
		    !ASSERT_EQ(splice(f.server, NULL, pipefd[1], NULL, 1, 0), 1, "splice") ||
		    !hint_is(&f, f.cpus[1]) ||
		    !ASSERT_EQ(read(pipefd[0], &value, 1), 1, "pipe_read") ||
		    !ASSERT_EQ(value, 'g', "splice_payload") ||
		    !transmit(&f, f.cpus[1], 'h') || !consume(&f, f.cpus[2], 'h'))
			goto out;
		{
			struct tcp_zerocopy_receive zc = {};
			socklen_t len = sizeof(zc);

			if (!ASSERT_OK(pin_cpu(f.cpus[1]), "pin_zerocopy") ||
			    !ASSERT_OK(getsockopt(f.server, SOL_TCP, TCP_ZEROCOPY_RECEIVE,
					  &zc, &len), "zerocopy_receive") ||
			    !hint_is(&f, f.cpus[1]))
				goto out;
		}
	} else if (!consume(&f, f.cpus[1], 'g')) {
		goto out;
	}
	if (type == SOCK_DGRAM) {
		/* Reuse the tuple after close: a new socket must not inherit a hint. */
		if (!ASSERT_OK(getsockname(f.server, (void *)&addr, &addrlen), "saved_addr"))
			goto out;
		close(f.server);
		f.server = start_server_addr(SOCK_DGRAM, &addr, addrlen, NULL);
		if (!ASSERT_OK_FD(f.server, "replacement_socket") ||
		    !ASSERT_OK(connect_fd_to_fd(f.server, f.client, 3000), "replacement_connect") ||
		    !ASSERT_ERR(bpf_map_lookup_elem(bpf_map__fd(f.skel->maps.socket_cpu),
						  &f.server, &hint), "no_stale_hint") ||
		    !transmit(&f, fallback_cpu, 'z') || !consume(&f, f.cpus[2], 'z'))
			goto out;
	}
out:
	if (pipefd[0] >= 0)
		close(pipefd[0]);
	if (pipefd[1] >= 0)
		close(pipefd[1]);
	cleanup(&f);
}

static void test_native_udp(int family)
{
	struct {
		__u16 pad;
		struct ethhdr eth;
		struct iphdr ip;
		struct udphdr udp;
		char value;
		char tail;
	} v4 = {};
	struct {
		__u16 pad;
		struct ethhdr eth;
		struct ipv6hdr ip;
		struct udphdr udp;
		char value;
		char tail;
	} v6 = {};
	size_t size4 = offsetof(typeof(v4), tail) + 1 - offsetof(typeof(v4), eth);
	size_t size6 = offsetof(typeof(v6), tail) + 1 - offsetof(typeof(v6), eth);
	struct rfs_fixture f;
	struct xdp_md ctx = {};
	__u32 before;
	int i, n, cpu, err;
	char value;

	LIBBPF_OPTS(bpf_test_run_opts, opts,
		    .ctx_in = &ctx,
		    .ctx_size_in = sizeof(ctx),
		    .flags = BPF_F_TEST_XDP_LIVE_FRAMES,
		    .repeat = 1,
	);

	if (!setup(&f, family, SOCK_DGRAM))
		goto out;
	/* Injected loopback frames have no output route attached to the skb. */
	if (family == AF_INET) {
		if (!ASSERT_OK(write_sysctl("/proc/sys/net/ipv4/conf/lo/accept_local", "1"),
			       "accept_injected_local_source") ||
		    !ASSERT_OK(write_sysctl("/proc/sys/net/ipv4/conf/lo/route_localnet", "1"),
			       "route_injected_loopback"))
			goto out;
	}
	/* Stop generic ingress before injecting native frames into this device. */
	if (!ASSERT_OK(bpf_xdp_detach(f.ifindex, XDP_FLAGS_SKB_MODE, NULL), "detach_generic"))
		goto out;
	f.attached = false;
	ctx.ingress_ifindex = f.ifindex;
	v4.eth.h_proto = htons(ETH_P_IP);
	v4.ip.version = 4;
	v4.ip.ihl = 5;
	v4.ip.ttl = 64;
	v4.ip.protocol = IPPROTO_UDP;
	v4.ip.tot_len = htons(size4 - sizeof(v4.eth));
	v4.ip.saddr = htonl(INADDR_LOOPBACK);
	v4.ip.daddr = htonl(INADDR_LOOPBACK);
	v4.ip.check = build_ip_csum(&v4.ip);
	v4.udp.source = get_socket_local_port(f.client);
	v4.udp.dest = f.skel->bss->server_port;
	v4.udp.len = htons(sizeof(v4.udp) + 2);
	v6.eth.h_proto = htons(ETH_P_IPV6);
	v6.ip.version = 6;
	v6.ip.nexthdr = IPPROTO_UDP;
	v6.ip.hop_limit = 64;
	v6.ip.payload_len = htons(sizeof(v6.udp) + 2);
	v6.ip.saddr = in6addr_loopback;
	v6.ip.daddr = in6addr_loopback;
	v6.udp = v4.udp;
	opts.data_in = family == AF_INET ? (void *)&v4.eth : (void *)&v6.eth;
	opts.data_size_in = family == AF_INET ? size4 : size6;
	ctx.data_end = opts.data_size_in;
	for (n = 0; n < 4; n++) {
		cpu = f.cpus[1 + (n & 1)];
		if (!ASSERT_OK(pin_cpu(cpu), "pin_native_reader"))
			goto out;
		recv(f.server, &value, 1, MSG_DONTWAIT);
		if (!hint_is(&f, cpu) || !ASSERT_OK(pin_cpu(f.cpus[0]), "pin_injector"))
			goto out;
		v4.value = 'a' + n;
		v6.value = 'a' + n;
		v6.udp.check = 0;
		v6.udp.check = build_udp_v6_csum(&v6.ip, &v6.udp);
		before = __atomic_load_n(&f.skel->bss->packets, __ATOMIC_RELAXED);
		err = bpf_prog_test_run_opts(bpf_program__fd(f.skel->progs.rfs_redirect), &opts);
		if (!ASSERT_OK(err, "native_inject"))
			goto out;
		for (i = 0; i < 5000; i++) {
			if (__atomic_load_n(&f.skel->bss->packets, __ATOMIC_RELAXED) > before)
				break;
			usleep(1000);
		}
		if (!ASSERT_LT(i, 5000, "native_stack_handoff") ||
		    !ASSERT_TRUE(drain(&f), "native_drain") ||
		    !ASSERT_EQ(f.skel->bss->receive_cpu, cpu, "native_receive_cpu") ||
		    !consume(&f, cpu, 'a' + n))
			goto out;
	}
out:
	cleanup(&f);
}

static void test_native_tcp_gro(void)
{
	struct {
		__u16 pad;
		struct ethhdr eth;
		struct iphdr ip;
		struct tcphdr tcp;
		char payload[RFS_GRO_PAYLOAD];
	} packet = {};
	struct rfs_fixture f;
	struct xdp_md ctx = {};
	char received[32 * RFS_GRO_PAYLOAD];
	char expected[sizeof(received)];
	const int count = sizeof(received) / RFS_GRO_PAYLOAD;
	int round, cpu;
	size_t size = sizeof(packet) - offsetof(typeof(packet), eth);

	LIBBPF_OPTS(bpf_test_run_opts, opts,
		    .data_in = &packet.eth,
		    .data_size_in = size,
		    .ctx_in = &ctx,
		    .ctx_size_in = sizeof(ctx),
		    .flags = BPF_F_TEST_XDP_LIVE_FRAMES,
		    .repeat = count,
		    .batch_size = count,
	);

	if (!setup(&f, AF_INET, SOCK_STREAM))
		goto out;
	if (!transmit(&f, f.cpus[1], 'a') || !consume(&f, f.cpus[1], 'a'))
		goto out;
	if (!ASSERT_OK(write_sysctl("/proc/sys/net/ipv4/conf/lo/accept_local", "1"),
		       "accept_local") ||
	    !ASSERT_OK(write_sysctl("/proc/sys/net/ipv4/conf/lo/route_localnet", "1"),
		       "route_localnet") ||
	    !ASSERT_OK(bpf_xdp_detach(f.ifindex, XDP_FLAGS_SKB_MODE, NULL), "detach_generic"))
		goto out;
	f.attached = false;
	ctx.ingress_ifindex = f.ifindex;
	ctx.data_end = size;
	packet.eth.h_proto = htons(ETH_P_IP);
	packet.ip = (struct iphdr) {
		.version = 4, .ihl = 5, .ttl = 64, .protocol = IPPROTO_TCP,
		.tot_len = htons(size - sizeof(packet.eth)),
		.frag_off = htons(0x4000),
		.saddr = htonl(INADDR_LOOPBACK), .daddr = htonl(INADDR_LOOPBACK),
	};
	packet.ip.check = build_ip_csum(&packet.ip);
	packet.tcp.source = get_socket_local_port(f.client);
	packet.tcp.dest = f.skel->bss->server_port;
	packet.tcp.ack_seq = htonl(f.skel->bss->last_tcp_ack);
	packet.tcp.doff = 5;
	packet.tcp.ack = 1;
	packet.tcp.window = htons(65535);
	memset(packet.payload, 'g', sizeof(packet.payload));
	memset(expected, 'g', sizeof(expected));
	f.skel->bss->batch_seq = f.skel->bss->last_tcp_seq + 1;
	for (round = 0; round < 2; round++) {
		cpu = f.cpus[1 + round];
		f.skel->bss->tcp_expected_cpu_plus_one = cpu + 1;
		if (!ASSERT_OK(pin_cpu(cpu), "pin_gro_reader"))
			goto out;
		recv(f.server, received, sizeof(received), MSG_DONTWAIT);
		if (!hint_is(&f, cpu) || !ASSERT_OK(pin_cpu(f.cpus[0]), "pin_gro_source") ||
		    !ASSERT_OK(bpf_prog_test_run_opts(bpf_program__fd(f.skel->progs.rfs_tcp_batch),
						     &opts), "tcp_native_burst") ||
		    !ASSERT_TRUE(drain(&f), "tcp_gro_drain") ||
		    /* Pure ACKs can arrive locally after generic XDP is detached. */
		    !ASSERT_EQ(f.skel->bss->tcp_data_cpu, cpu, "tcp_gro_cpu") ||
		    !ASSERT_EQ(f.skel->bss->tcp_wrong_cpu, 0, "all_tcp_data_on_target") ||
		    !ASSERT_OK(pin_cpu(cpu), "pin_tcp_consumer") ||
		    !ASSERT_EQ(recv(f.server, received, sizeof(received), MSG_WAITALL),
			       sizeof(received), "tcp_burst_delivered"))
			goto out;
		if (!ASSERT_MEMEQ(received, expected, sizeof(received), "tcp_burst_payload"))
			goto out;
	}
	ASSERT_GT(f.skel->bss->gro_packets, 0, "tcp_gro_aggregated");
	ASSERT_GT(f.skel->bss->gro_segments, f.skel->bss->gro_packets, "tcp_gro_segments");
out:
	cleanup(&f);
}

static void test_classification(void)
{
	struct ipv4_packet packet = pkt_v4;
	struct rfs_fixture f;
	__u64 before;
	int fd;

	LIBBPF_OPTS(bpf_test_run_opts, opts,
		    .data_in = &packet,
		    .data_size_in = sizeof(packet),
	);

	if (!setup(&f, AF_INET, SOCK_DGRAM))
		goto out;
	fd = bpf_program__fd(f.skel->progs.rfs_redirect);
	/* This TCP tuple has no socket. It must still request ordered redirect. */
	packet.iph.version = 4;
	packet.iph.tot_len = htons(sizeof(packet) - sizeof(packet.eth));
	before = stat_sum(&f, RFS_FALLBACK);
	if (!ASSERT_OK(bpf_prog_test_run_opts(fd, &opts), "lookup_miss") ||
	    !ASSERT_EQ(opts.retval, XDP_REDIRECT, "miss_stays_ordered") ||
	    !ASSERT_GT(stat_sum(&f, RFS_FALLBACK), before, "lookup_miss_fallback"))
		goto out;
	opts.data_size_in = sizeof(packet.eth);
	if (!ASSERT_OK(bpf_prog_test_run_opts(fd, &opts), "truncated_ip") ||
	    !ASSERT_EQ(opts.retval, XDP_DROP, "truncated_drop"))
		goto out;
	opts.data_size_in = sizeof(packet);
	opts.data_size_out = 0;
	packet.iph.frag_off = htons(0x2000);
	if (!ASSERT_OK(bpf_prog_test_run_opts(fd, &opts), "fragment") ||
	    !ASSERT_EQ(opts.retval, XDP_PASS, "fragment_outside_scope"))
		goto out;
	packet.iph.frag_off = 0;
	opts.data_size_out = 0;
	packet.eth.h_proto = htons(ETH_P_ARP);
	if (!ASSERT_OK(bpf_prog_test_run_opts(fd, &opts), "arp") ||
	    !ASSERT_EQ(opts.retval, XDP_PASS, "arp_pass"))
		goto out;
	packet.eth.h_proto = htons(ETH_P_IP);
	opts.data_size_out = 0;
	packet.eth.h_dest[0] = 1;
	if (!ASSERT_OK(bpf_prog_test_run_opts(fd, &opts), "multicast") ||
	    !ASSERT_EQ(opts.retval, XDP_PASS, "multicast_pass"))
		goto out;
out:
	cleanup(&f);
}

static void test_measurement_policy(__u32 policy)
{
	struct rfs_fixture f;
	int target;

	test_policy_kind = policy;
	test_ordered = false;
	if (!setup(&f, AF_INET, SOCK_DGRAM))
		goto out;
	if (!transmit(&f, -1, 'a'))
		goto out;
	target = f.skel->bss->receive_cpu;
	/* Both baselines retain hash placement even after an application move. */
	if (!consume(&f, f.cpus[2], 'a') ||
	    !transmit(&f, target, 'b') || !consume(&f, f.cpus[1], 'b') ||
	    !transmit(&f, target, 'c') || !consume(&f, f.cpus[2], 'c'))
		goto out;
	if (policy == RFS_POLICY_LOOKUP)
		ASSERT_GT(stat_sum(&f, RFS_HINT), 0, "lookup_baseline_read_hint");
	else
		ASSERT_EQ(stat_sum(&f, RFS_HINT), 0, "hash_baseline_no_lookup");
out:
	cleanup(&f);
	test_policy_kind = RFS_POLICY_SOCKET;
	test_ordered = true;
}

static void test_mptcp(int family)
{
	struct mptcp_info info = {};
	socklen_t len = sizeof(info);
	struct rfs_fixture f;
	int fd = socket(family, SOCK_STREAM, IPPROTO_MPTCP);

	if (fd < 0 && (errno == EPROTONOSUPPORT || errno == EAFNOSUPPORT)) {
		printf("SKIP: MPTCP is not configured\n");
		test__skip();
		return;
	}
	if (!ASSERT_OK_FD(fd, "mptcp_available"))
		return;
	close(fd);
	test_protocol = IPPROTO_MPTCP;
	if (!setup(&f, family, SOCK_STREAM))
		goto out;
	if (!ASSERT_OK(getsockopt(f.server, SOL_MPTCP, MPTCP_INFO, &info, &len), "mptcp_info") ||
	    !ASSERT_EQ(info.mptcpi_flags & MPTCP_INFO_FLAG_FALLBACK, 0, "real_mptcp") ||
	    !transmit(&f, f.cpus[1], 'm') || !consume(&f, f.cpus[2], 'm') ||
	    !transmit(&f, f.cpus[2], 'p') || !consume(&f, f.cpus[1], 'p') ||
	    !transmit(&f, f.cpus[1], 't') || !consume(&f, f.cpus[1], 't'))
		goto out;
out:
	cleanup(&f);
	test_protocol = 0;
}

static void test_sctp(int family)
{
	struct rfs_fixture f;
	__u64 hits;

	test_protocol = IPPROTO_SCTP;
	if (!setup(&f, family, SOCK_STREAM))
		goto out;
	hits = stat_sum(&f, RFS_HINT);
	if (!transmit(&f, f.cpus[1], 's') || !consume(&f, f.cpus[2], 's') ||
	    !transmit(&f, f.cpus[2], 'c') || !consume(&f, f.cpus[1], 'c') ||
	    !transmit(&f, f.cpus[1], 't') || !consume(&f, f.cpus[1], 't'))
		goto out;
	ASSERT_GT(stat_sum(&f, RFS_HINT), hits, "sctp_socket_lookup");
out:
	cleanup(&f);
	test_protocol = 0;
}

static bool set_load(struct rfs_fixture *f, int cpu, __u32 util, bool fresh)
{
	struct timespec now;
	struct rfs_load load;
	__u32 key = cpu;

	clock_gettime(CLOCK_MONOTONIC, &now);
	load.util = util;
	load.updated_ms = fresh ? (__u32)(now.tv_sec * 1000 + now.tv_nsec / 1000000) : 1;
	return ASSERT_OK(bpf_map_update_elem(bpf_map__fd(f->skel->maps.cpu_load),
					    &key, &load, BPF_ANY), "set_cpu_load");
}

static void test_hardware_intents(void)
{
	struct rfs_flow_key dummy = { .family = AF_INET, .protocol = IPPROTO_UDP }, actual;
	struct rfs_hw_flow intent = {};
	struct rfs_fixture f;
	__u64 failures;
	int fd;
	char byte;

	test_hardware = 2;
	if (!setup(&f, AF_INET, SOCK_DGRAM))
		goto out;
	fd = bpf_map__fd(f.skel->maps.hw_flows);
	if (!ASSERT_OK(bpf_map_update_elem(fd, &dummy, &intent, BPF_NOEXIST), "fill_intent_map") ||
	    !ASSERT_OK(pin_cpu(f.cpus[2]), "pin_hardware_hint"))
		goto out;
	recv(f.server, &byte, 1, MSG_DONTWAIT);
	failures = stat_sum(&f, RFS_HW_FULL);
	if (!transmit(&f, f.cpus[2], 'h') || !consume(&f, f.cpus[2], 'h') ||
	    !ASSERT_GT(stat_sum(&f, RFS_HW_FULL), failures, "full_map_keeps_software_rfs") ||
	    !ASSERT_OK(bpf_map_delete_elem(fd, &dummy), "free_intent_slot") ||
	    !transmit(&f, f.cpus[2], 'i') || !consume(&f, f.cpus[1], 'i') ||
	    !ASSERT_OK(bpf_map_get_next_key(fd, NULL, &actual), "intent_key") ||
	    !ASSERT_OK(bpf_map_lookup_elem_flags(fd, &actual, &intent, BPF_F_LOCK),
		       "intent_snapshot") ||
	    !ASSERT_EQ(intent.cpu, f.cpus[2], "hardware_socket_cpu") ||
	    !ASSERT_EQ(intent.generation, 1, "first_generation") ||
	    !transmit(&f, f.cpus[1], 'j') || !consume(&f, f.cpus[1], 'j') ||
	    !ASSERT_OK(bpf_map_lookup_elem_flags(fd, &actual, &intent, BPF_F_LOCK),
		       "new_intent_snapshot"))
		goto out;
	ASSERT_EQ(intent.cpu, f.cpus[1], "hardware_migrated_cpu");
	ASSERT_EQ(intent.generation, 2, "hardware_generation");
out:
	cleanup(&f);
	test_hardware = 0;
}

static void test_load_policy(void)
{
	struct bpf_cpumap_val entry = { .qsize = 2048 };
	struct rfs_llc group = { .id = 1, .count = 3 };
	struct rfs_fixture f;
	__u32 key, one = 1;
	int i;
	char byte;

	test_policy_kind = RFS_POLICY_LLC_LOAD;
	if (!setup(&f, AF_INET, SOCK_DGRAM))
		goto out;
	key = f.cpus[0];
	if (!ASSERT_OK(bpf_map_update_elem(bpf_map__fd(f.skel->maps.cpu_map),
					   &key, &entry, BPF_ANY), "load_extra_cpu") ||
	    !ASSERT_OK(bpf_map_update_elem(bpf_map__fd(f.skel->maps.allowed),
					  &key, &one, BPF_ANY), "load_allow_extra_cpu"))
		goto out;
	for (i = 0; i < 3; i++)
		group.cpus[i] = f.cpus[i];
	for (i = 0; i < 3; i++) {
		key = f.cpus[i];
		if (!ASSERT_OK(bpf_map_update_elem(bpf_map__fd(f.skel->maps.llc),
						   &key, &group, BPF_ANY), "load_topology"))
			goto out;
	}
	if (!ASSERT_OK(pin_cpu(f.cpus[1]), "pin_load_application"))
		goto out;
	recv(f.server, &byte, 1, MSG_DONTWAIT);
	if (!hint_is(&f, f.cpus[1]) ||
	    !set_load(&f, f.cpus[0], 900, true) || !set_load(&f, f.cpus[2], 100, true) ||
	    !transmit(&f, f.cpus[2], 'l') || !consume(&f, f.cpus[1], 'l'))
		goto out;
	/* A small improvement must not trigger a move after the dwell period. */
	usleep(600000);
	if (!set_load(&f, f.cpus[0], 50, true) || !set_load(&f, f.cpus[2], 100, true) ||
	    !transmit(&f, f.cpus[2], 'm') || !consume(&f, f.cpus[1], 'm'))
		goto out;
	if (!set_load(&f, f.cpus[0], 0, true) || !set_load(&f, f.cpus[2], 900, true) ||
	    !transmit(&f, f.cpus[0], 'n') || !consume(&f, f.cpus[1], 'n'))
		goto out;
	if (!set_load(&f, f.cpus[0], 900, true) || !set_load(&f, f.cpus[2], 0, true) ||
	    !transmit(&f, f.cpus[0], 'o') || !consume(&f, f.cpus[1], 'o'))
		goto out;
	/* Stale telemetry falls back to the socket hint through the same domain. */
	if (!set_load(&f, f.cpus[0], 0, false) || !set_load(&f, f.cpus[2], 0, false) ||
	    !transmit(&f, f.cpus[1], 'p') || !consume(&f, f.cpus[1], 'p'))
		goto out;
	ASSERT_GT(stat_sum(&f, RFS_LOAD_SELECTED), 0, "load_policy_used");
out:
	cleanup(&f);
	test_policy_kind = RFS_POLICY_SOCKET;
}

void test_external_xdp_rfs(void)
{
	if (test__start_subtest("plain_hash"))
		test_measurement_policy(RFS_POLICY_HASH);
	if (test__start_subtest("plain_lookup"))
		test_measurement_policy(RFS_POLICY_LOOKUP);
	if (test__start_subtest("hardware_intents"))
		test_hardware_intents();
	if (test__start_subtest("sctp_ipv4"))
		test_sctp(AF_INET);
	if (test__start_subtest("sctp_ipv6"))
		test_sctp(AF_INET6);
	if (test__start_subtest("llc_load"))
		test_load_policy();
	if (test__start_subtest("mptcp_ipv4"))
		test_mptcp(AF_INET);
	if (test__start_subtest("mptcp_ipv6"))
		test_mptcp(AF_INET6);
	if (test__start_subtest("native_tcp_gro"))
		test_native_tcp_gro();
	if (test__start_subtest("tcp_ipv4"))
		test_policy(AF_INET, SOCK_STREAM);
	if (test__start_subtest("tcp_ipv6"))
		test_policy(AF_INET6, SOCK_STREAM);
	if (test__start_subtest("udp_ipv4"))
		test_policy(AF_INET, SOCK_DGRAM);
	if (test__start_subtest("udp_ipv6"))
		test_policy(AF_INET6, SOCK_DGRAM);
	if (test__start_subtest("native_udp_ipv4"))
		test_native_udp(AF_INET);
	if (test__start_subtest("native_udp_ipv6"))
		test_native_udp(AF_INET6);
	if (test__start_subtest("classification"))
		test_classification();
}
