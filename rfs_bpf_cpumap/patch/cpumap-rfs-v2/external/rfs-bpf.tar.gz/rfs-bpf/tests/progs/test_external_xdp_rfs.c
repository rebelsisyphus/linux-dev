// SPDX-License-Identifier: GPL-2.0
#include "xdp_rfs.bpf.c"
#include "test_external_xdp_rfs.h"

__u16 server_port;
__u32 packets, receive_cpu;
__u32 last_tcp_seq, last_tcp_ack, gro_packets, gro_segments;
__u32 tcp_data_cpu, tcp_expected_cpu_plus_one, tcp_wrong_cpu;
__u32 batch_seq, batch_index;

/* Synthesize a sequential TCP burst, then run the same steering policy. */
SEC("xdp.frags")
int rfs_tcp_batch(struct xdp_md *ctx)
{
	void *data = (void *)(long)ctx->data;
	void *end = (void *)(long)ctx->data_end;
	struct ethhdr *eth = data;
	struct iphdr *ip = (void *)(eth + 1);
	struct tcphdr *tcp = (void *)(ip + 1);
	struct {
		__be32 saddr, daddr;
		__u8 zero, protocol;
		__be16 len;
	} pseudo = {};
	__u32 sum, index;

	if ((void *)(tcp + 1) + RFS_GRO_PAYLOAD > end)
		return XDP_DROP;
	/* This unattached generator has one test-run producer. */
	index = batch_index++;
	tcp->seq = bpf_htonl(batch_seq + index * RFS_GRO_PAYLOAD);
	tcp->check = 0;
	pseudo.saddr = ip->saddr;
	pseudo.daddr = ip->daddr;
	pseudo.protocol = IPPROTO_TCP;
	pseudo.len = bpf_htons(sizeof(*tcp) + RFS_GRO_PAYLOAD);
	sum = bpf_csum_diff(NULL, 0, (void *)&pseudo, sizeof(pseudo), 0);
	sum = bpf_csum_diff(NULL, 0, (void *)tcp, sizeof(*tcp) + RFS_GRO_PAYLOAD, sum);
	sum = (sum & 0xffff) + (sum >> 16);
	sum = (sum & 0xffff) + (sum >> 16);
	tcp->check = ~sum;
	return rfs_select(ctx);
}

/* Observe the real stack handoff, after CPUMAP has constructed an skb. */
SEC("tc")
int rfs_receive(struct __sk_buff *skb)
{
	void *data = (void *)(long)skb->data;
	void *end = (void *)(long)skb->data_end;
	struct ethhdr *eth = data;
	__be16 *ports;
	__u8 protocol;

	if ((void *)(eth + 1) > end)
		return 0;
	if (eth->h_proto == bpf_htons(0x0800)) {
		struct iphdr *ip = (void *)(eth + 1);

		if ((void *)(ip + 1) > end || ip->ihl < 5)
			return 0;
		ports = (void *)ip + ip->ihl * 4;
		protocol = ip->protocol;
	} else if (eth->h_proto == bpf_htons(0x86dd)) {
		struct ipv6hdr *ip = (void *)(eth + 1);

		if ((void *)(ip + 1) > end)
			return 0;
		ports = (void *)(ip + 1);
		protocol = ip->nexthdr;
	} else {
		return 0;
	}
	if ((protocol != IPPROTO_TCP && protocol != IPPROTO_UDP &&
	     protocol != IPPROTO_SCTP) ||
	    (void *)(ports + 2) > end || ports[1] != server_port)
		return 0;
	if (protocol == IPPROTO_TCP) {
		struct tcphdr *tcp = (void *)ports;

		if ((void *)(tcp + 1) <= end &&
		    skb->len > (void *)tcp - data + tcp->doff * 4) {
			__u32 cpu = bpf_get_smp_processor_id();

			last_tcp_seq = bpf_ntohl(tcp->seq);
			last_tcp_ack = bpf_ntohl(tcp->ack_seq);
			tcp_data_cpu = cpu;
			if (tcp_expected_cpu_plus_one &&
			    cpu + 1 != tcp_expected_cpu_plus_one)
				__sync_fetch_and_add(&tcp_wrong_cpu, 1);
		}
		if (skb->gso_segs > 1) {
			__sync_fetch_and_add(&gro_packets, 1);
			__sync_fetch_and_add(&gro_segments, skb->gso_segs);
		}
	}
	receive_cpu = bpf_get_smp_processor_id();
	__sync_fetch_and_add(&packets, 1);
	return 0;
}
