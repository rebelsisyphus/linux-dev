/* SPDX-License-Identifier: GPL-2.0 */
#ifndef RFS_TEST_H
#define RFS_TEST_H
#define RFS_GRO_PAYLOAD 64
#endif
