#!/bin/bash
# SPDX-License-Identifier: GPL-2.0
# Run only in an isolated VM: this test changes global CPU online state.
set -euo pipefail
cd /mnt/shared
ns=rfs_hotplug_$$
loader_pid=
cleanup()
{
    echo 1 >/sys/devices/system/cpu/cpu1/online
    ip -n "$ns" link set lo down 2>/dev/null || true
    if [[ -n $loader_pid ]]; then
        kill -CONT "$loader_pid" 2>/dev/null || true
        kill -TERM "$loader_pid" 2>/dev/null || true
        wait "$loader_pid" 2>/dev/null || true
    fi
    ip netns del "$ns" 2>/dev/null || true
}
trap cleanup EXIT
wait_log()
{
    local pattern=$1 count=$2
    for i in $(seq 1 300); do
        if [[ $(grep -c "$pattern" rfs-hotplug.log || true) -ge $count ]]; then
            return 0
        fi
        kill -0 "$loader_pid"
        sleep .1
    done
    cat rfs-hotplug.log
    return 1
}
check_udp()
{
    ip netns exec "$ns" python3 - <<'PY'
import os, socket
os.sched_setaffinity(0, {2})
with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as server, \
     socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as client:
    server.bind(('127.0.0.1', 0))
    client.connect(server.getsockname())
    server.connect(client.getsockname())
    server.settimeout(3)
    for i in range(32):
        payload = str(i).encode()
        client.send(payload)
        assert server.recv(128) == payload
PY
}
ip netns add "$ns"
ip netns exec "$ns" ./xdp_rfs -S -i lo -c 1,2 >rfs-hotplug.log 2>&1 &
loader_pid=$!
wait_log '^ready ' 1
ip -n "$ns" link set lo up
check_udp
echo 0 >/sys/devices/system/cpu/cpu1/online
wait_log '^cpu 1 withdrawn' 1
check_udp
echo 1 >/sys/devices/system/cpu/cpu1/online
wait_log '^cpu 1 online: queue recreated' 2
# A full hotplug cycle while userspace is stopped must not escape detection.
kill -STOP "$loader_pid"
echo 0 >/sys/devices/system/cpu/cpu1/online
echo 1 >/sys/devices/system/cpu/cpu1/online
kill -CONT "$loader_pid"
wait_log '^cpu 1 online: queue recreated' 3
check_udp
# Ignore retired workers while RCU teardown runs; a new worker must be pinned.
found=0
for i in $(seq 1 100); do
    for comm in /proc/[0-9]*/comm; do
        read -r name <"$comm" || continue
        if [[ $name == cpumap/1/map:* ]] &&
           grep -q $'^Cpus_allowed_list:\t1$' "${comm%comm}status"; then
            found=1
            break
        fi
    done
    [[ $found == 1 ]] && break
    sleep .1
done
test "$found" -eq 1
ip -n "$ns" link set lo down
kill -TERM "$loader_pid"
wait "$loader_pid"
loader_pid=
cat rfs-hotplug.log
echo 'RFS hotplug recovery passed'
