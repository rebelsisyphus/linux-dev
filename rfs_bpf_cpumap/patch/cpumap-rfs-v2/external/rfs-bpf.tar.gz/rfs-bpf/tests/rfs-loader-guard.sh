#!/bin/bash
set -euo pipefail
# Exercise the real loader against isolated sysfs queue attributes, including
# RFS enabled with rps_cpus=0. The test kernel itself has CONFIG_RPS=n.
for interface in lo 'rfs[0]'; do
RFS_IFNAME="$interface" unshare --mount --net bash -euo pipefail <<'GUEST'
mount --make-rprivate /
if [[ $RFS_IFNAME != lo ]]; then
    ip link set lo name "$RFS_IFNAME"
fi
mount -t sysfs sysfs /sys
queue=/sys/class/net/$RFS_IFNAME/queues
fixture=$(mktemp -d)
trap 'umount "$queue" 2>/dev/null || true; rm -rf "$fixture"' EXIT
mkdir "$fixture/rx-0"
mount --bind "$fixture" "$queue"
for enabled in rps_flow_cnt rps_cpus; do
    printf '0\n' >"$fixture/rx-0/rps_cpus"
    printf '0\n' >"$fixture/rx-0/rps_flow_cnt"
    printf '1\n' >"$fixture/rx-0/$enabled"
    set +e
    timeout 15 /mnt/shared/xdp_rfs -S -i "$RFS_IFNAME" -c 1,2 >"/mnt/shared/guard-$RFS_IFNAME-$enabled.log" 2>&1
    status=$?
    set -e
    test "$status" -eq 1
    grep -q 'native RPS/RFS disabled' "/mnt/shared/guard-$RFS_IFNAME-$enabled.log"
done
echo "RFS loader RPS and RFS exclusion checks passed: $RFS_IFNAME"
GUEST
done
