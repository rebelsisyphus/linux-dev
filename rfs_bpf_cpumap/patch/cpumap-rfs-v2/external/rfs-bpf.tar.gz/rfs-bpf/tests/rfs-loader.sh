#!/bin/bash
set -euo pipefail
cd /mnt/shared
ns=rfs_loader_$$
loader_pid=
cleanup()
{
    ip -n "$ns" link set lo down 2>/dev/null || true
    if [[ -n $loader_pid ]]; then
        kill -TERM "$loader_pid" 2>/dev/null || true
        wait "$loader_pid" 2>/dev/null || true
    fi
    ip netns del "$ns" 2>/dev/null || true
}
trap cleanup EXIT
ip netns add "$ns"
ip netns exec "$ns" ./xdp_rfs -S -i lo -c 1,2 >rfs-loader.log 2>&1 &
loader_pid=$!
ready=0
for i in $(seq 1 300); do
    if grep -q '^ready ' rfs-loader.log; then
        ready=1
        break
    fi
    kill -0 "$loader_pid"
    sleep .1
done
if [[ $ready != 1 ]]; then
    cat rfs-loader.log
    exit 1
fi
# Refuse to replace the attached program, even while the interface is down.
if ip netns exec "$ns" ./xdp_rfs -S -i lo -c 1,2 >rfs-loader-duplicate.log 2>&1; then
    exit 1
fi
ip -n "$ns" link set lo up
kill -TERM "$loader_pid"
sleep 1
kill -0 "$loader_pid"
ip -n "$ns" -details link show lo >rfs-loader-attached.log
grep -q 'prog/xdp' rfs-loader-attached.log
ip -n "$ns" link set lo down
wait "$loader_pid"
loader_pid=
ip -n "$ns" -details link show lo >rfs-loader-detached.log
if grep -q 'prog/xdp' rfs-loader-detached.log; then
    exit 1
fi
cat rfs-loader.log
echo 'RFS loader lifecycle passed'
