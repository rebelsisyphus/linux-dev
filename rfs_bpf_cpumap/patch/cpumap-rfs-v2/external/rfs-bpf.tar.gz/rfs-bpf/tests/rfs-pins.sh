#!/bin/bash
# Isolated VM only: exercise the actual hardware hint/control ABI without a NIC.
set -euo pipefail
cd /mnt/shared
ns=rfs_pins_$$
mountdir=/mnt/rfs-pins-$$
pins=$mountdir/maps
loader=
cleanup()
{
    ip -n "$ns" link set lo down 2>/dev/null || true
    if [[ -n $loader ]]; then
        kill -TERM "$loader" 2>/dev/null || true
        wait "$loader" 2>/dev/null || true
    fi
    ip netns del "$ns" 2>/dev/null || true
    rm -f "$pins/flows" "$pins/config" "$pins/allowed"
    rmdir "$pins" 2>/dev/null || true
    umount "$mountdir" 2>/dev/null || true
    rmdir "$mountdir" 2>/dev/null || true
}
trap cleanup EXIT
# ip netns exec mounts its own sysfs; use bpffs outside /sys for shared pins.
mkdir "$mountdir"
mount -t bpf none "$mountdir"
ip netns add "$ns"
ip netns exec "$ns" ./xdp_rfs -S -i lo -c 1,2 -H "$pins" -N >rfs-pins.log 2>&1 &
loader=$!
for i in $(seq 1 300); do
    if grep -q '^ready ' rfs-pins.log; then break; fi
    kill -0 "$loader"
    sleep .1
done
grep -q '^ready ' rfs-pins.log
ip -n "$ns" link set lo up
ip netns exec "$ns" python3 - "$pins" <<'PY'
import json, os, socket, struct, subprocess, sys
from hw_steer import BpfMap
pins = sys.argv[1]
cfg = BpfMap(pins + '/config', 4, 16, 2, readonly=True)
abi, ifindex, netns, prog = struct.unpack('=4I', cfg.lookup(struct.pack('=I', 0)))
assert abi == 1 and ifindex == socket.if_nametoindex('lo')
assert netns == os.stat('/proc/self/ns/net').st_ino and prog > 0
link = json.loads(subprocess.check_output(['ip', '-j', '-d', 'link', 'show', 'dev', 'lo']))[0]
assert link['xdp']['prog']['id'] == prog
flows = BpfMap(pins + '/flows', 40, 24, 1)
server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server.bind(('127.0.0.1', 0))
client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
client.connect(server.getsockname())
server.connect(client.getsockname())
server.settimeout(3)
for cpu in (2, 1):
    os.sched_setaffinity(0, {cpu})
    server.setblocking(False)
    try: server.recv(1, socket.MSG_DONTWAIT)
    except BlockingIOError: pass
    server.settimeout(3)
    os.sched_setaffinity(0, {0})
    client.send(b'x')
    assert server.recv(1) == b'x'
    entries = list(flows.entries())
    assert len(entries) == 1
    _, actual, seen, generation = struct.unpack('=IIQQ', entries[0][1])
    assert actual == cpu and seen > 0
    assert generation == (1 if cpu == 2 else 2)
print('hardware map ABI and locked snapshots passed')
PY
ip -n "$ns" link set lo down
kill -TERM "$loader"
wait "$loader"
loader=
test ! -e "$pins"
echo 'RFS hardware map lifecycle passed'
