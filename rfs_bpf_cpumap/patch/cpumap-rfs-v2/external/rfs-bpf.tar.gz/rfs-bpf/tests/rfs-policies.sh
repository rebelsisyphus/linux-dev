#!/bin/bash
# Isolated four-CPU VM: exercise loader modes and real topology/stat sampling.
set -euo pipefail
cd /mnt/shared
ns=rfs_policies_$$
loader=
cleanup()
{
    ip -n "$ns" link set lo down 2>/dev/null || true
    if [[ -n $loader ]]; then
        kill -TERM "$loader" 2>/dev/null || true
        wait "$loader" 2>/dev/null || true
    fi
    ip netns del "$ns" 2>/dev/null || true
}
trap cleanup EXIT
ip netns add "$ns"
for mode in hash lookup llc-load; do
    extra=()
    [[ $mode == llc-load ]] || extra=(-U)
    logfile=rfs-policy-$mode.log
    ip netns exec "$ns" ./xdp_rfs -S -i lo -c 1,2 -p "$mode" -s 1234 \
        "${extra[@]}" >"$logfile" 2>&1 &
    loader=$!
    for i in $(seq 1 300); do
        if grep -q '^ready ' "$logfile"; then break; fi
        kill -0 "$loader"
        sleep .1
    done
    grep -q '^ready ' "$logfile"
    ip -n "$ns" link set lo up
    sleep 1
    ip netns exec "$ns" python3 - <<'PY'
import os, socket
server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server.bind(('127.0.0.1', 0))
client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
client.connect(server.getsockname())
server.connect(client.getsockname())
server.settimeout(3)
for i in range(32):
    os.sched_setaffinity(0, {0})
    payload = str(i).encode()
    client.send(payload)
    os.sched_setaffinity(0, {1})
    assert server.recv(128) == payload
PY
    ip -n "$ns" link set lo down
    kill -TERM "$loader"
    wait "$loader"
    loader=
    cat "$logfile"
done
echo 'RFS loader measurement modes and load sampler passed'
