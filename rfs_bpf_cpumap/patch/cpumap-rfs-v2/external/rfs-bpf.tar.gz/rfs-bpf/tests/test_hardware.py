# SPDX-License-Identifier: GPL-2.0
import ctypes
import errno
import importlib.util
from pathlib import Path
import socket
import struct
import subprocess
import tempfile
import unittest

MODULE = Path(__file__).resolve().parents[1] / 'tools/hw_steer.py'
spec = importlib.util.spec_from_file_location('hw_steer', MODULE)
hw = importlib.util.module_from_spec(spec)
spec.loader.exec_module(hw)


def key(family=socket.AF_INET, protocol=6, port=1234):
    addr = socket.inet_pton(family, '127.0.0.1' if family == socket.AF_INET else '::1')
    return addr.ljust(16, b'\0') * 2 + struct.pack('!HH', port, 8080) + struct.pack('=HBB', family, protocol, 0)


class MemoryJournal:
    def __init__(self):
        self.rules, self.snapshots = {}, []
        self.fail = False

    def save(self):
        if self.fail:
            raise OSError(errno.ENOSPC, 'journal full')
        self.snapshots.append({k: v.copy() for k, v in self.rules.items()})


class Backend:
    def __init__(self, journal):
        self.table, self.operations = {}, []
        self.journal = journal
        self.fail_put = self.fail_delete = self.bad_ack = False

    def get(self, location):
        return self.table.get(location)

    def put(self, rule):
        location = hw.FlowSpec.from_buffer_copy(rule).location
        assert self.journal.snapshots[-1][str(location)]['state'] == 'pending'
        if self.fail_put:
            raise OSError(errno.ENOSPC, 'NIC table full')
        self.operations.append(('put', location))
        if self.bad_ack:
            altered = hw.FlowSpec.from_buffer_copy(rule)
            altered.queue += 1
            rule = hw.spec_bytes(altered)
        self.table[location] = rule

    def delete(self, location):
        if self.fail_delete:
            raise OSError(errno.EIO, 'device unavailable')
        self.operations.append(('delete', location))
        self.table.pop(location, None)


class HardwareTests(unittest.TestCase):
    def setUp(self):
        self.journal = MemoryJournal()
        self.nic = Backend(self.journal)
        self.ctl = hw.Controller(self.nic, self.journal, range(8, 10), {1: 0, 2: 1})

    def test_confirmed_insert_and_generation(self):
        self.ctl.reconcile({key(): (1, 1)})
        self.assertEqual(self.journal.rules['8']['state'], 'active')
        self.ctl.reconcile({key(): (1, 3)})
        self.assertEqual(self.journal.rules['8']['generation'], 3)
        self.assertEqual(self.nic.operations, [('put', 8)])

    def test_move_deletes_old_before_install(self):
        self.ctl.reconcile({key(): (1, 1)})
        self.ctl.reconcile({key(): (2, 2)})
        self.assertEqual(self.nic.operations, [('put', 8), ('delete', 8), ('put', 8)])
        self.assertEqual(hw.FlowSpec.from_buffer_copy(self.nic.table[8]).queue, 1)

    def test_expire_and_unmapped_cpu(self):
        self.ctl.reconcile({key(): (1, 1)})
        self.ctl.reconcile({key(): (7, 2)})
        self.assertEqual(self.nic.table, {})
        self.assertEqual(self.journal.rules, {})

    def test_other_rules_are_not_overwritten(self):
        foreign = hw.make_rule(key(port=44), 3, 8)
        self.nic.table = {8: foreign, 9: hw.make_rule(key(port=45), 3, 9)}
        self.ctl.reconcile({key(): (1, 1)})
        self.assertEqual(self.nic.table[8], foreign)
        self.assertEqual(self.nic.operations, [])
        self.assertEqual(self.ctl.counters['full'], 1)

    def test_replaced_rule_is_not_deleted(self):
        self.ctl.reconcile({key(): (1, 1)})
        foreign = hw.make_rule(key(port=44), 3, 8)
        self.nic.table[8] = foreign
        with self.assertRaises(RuntimeError):
            self.ctl.recover()
        self.assertEqual(self.nic.table[8], foreign)
        self.assertIn('8', self.journal.rules)

    def test_failed_insertion_remains_recoverable(self):
        self.nic.fail_put = True
        with self.assertRaises(OSError):
            self.ctl.reconcile({key(): (1, 1)})
        self.assertEqual(self.journal.rules['8']['state'], 'pending')
        self.ctl.recover()
        self.assertEqual(self.journal.rules, {})

    def test_unconfirmed_insert_is_not_reported_active(self):
        self.nic.bad_ack = True
        with self.assertRaises(RuntimeError):
            self.ctl.reconcile({key(): (1, 1)})
        self.assertEqual(self.journal.rules['8']['state'], 'pending')
        with self.assertRaises(RuntimeError):
            self.ctl.recover()
        self.assertEqual(self.ctl.counters['installed'], 0)

    def test_failed_delete_keeps_tombstone(self):
        self.ctl.reconcile({key(): (1, 1)})
        self.nic.fail_delete = True
        with self.assertRaises(OSError):
            self.ctl.reconcile({})
        self.assertIn('8', self.journal.rules)
        self.nic.fail_delete = False
        self.ctl.recover()
        self.assertEqual(self.journal.rules, {})

    def test_crash_after_insert_before_ack(self):
        rule = hw.make_rule(key(), 0, 8)
        self.journal.rules['8'] = {'key': key().hex(), 'spec': rule.hex(),
                                   'generation': 1, 'state': 'pending'}
        self.journal.save()
        self.nic.put(rule)
        restarted = hw.Controller(self.nic, self.journal, range(8, 10), {1: 0})
        restarted.recover()
        self.assertEqual(self.nic.table, {})

    def test_journal_failure_prevents_nic_write(self):
        self.journal.fail = True
        with self.assertRaises(OSError):
            self.ctl.reconcile({key(): (1, 1)})
        self.assertEqual(self.nic.table, {})

    def test_device_reset_reinstalls_after_readback(self):
        self.ctl.reconcile({key(): (1, 1)})
        self.nic.table.clear()
        self.ctl.reconcile({key(): (1, 1)})
        self.assertEqual(len(self.nic.table), 1)
        self.assertEqual(self.ctl.counters['installed'], 2)

    def test_device_replacement_does_not_cleanup_foreign_device(self):
        self.ctl.reconcile({key(): (1, 1)})
        self.nic.identity = lambda: {'ifindex': 7}
        with self.assertRaises(RuntimeError):
            self.ctl.recover_device({'ifindex': 6})
        self.assertEqual(self.nic.operations, [('put', 8)])
        self.assertIn('8', self.journal.rules)

    def test_exact_protocol_rules(self):
        for family in (socket.AF_INET, socket.AF_INET6):
            for protocol in (6, 17, 132):
                rule = hw.FlowSpec.from_buffer_copy(hw.make_rule(key(family, protocol), 3, 8))
                n = 12 if family == socket.AF_INET else 36
                self.assertEqual(bytes(rule.mask.raw[:n]), b'\xff' * n)
                self.assertEqual(bytes(rule.mask.raw[n:]), b'\0' * (52 - n))
                self.assertEqual(rule.queue, 3)

    def test_durable_journal_identity(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'journal'
            j = hw.Journal(path, {'device': 1})
            j.rules['8'] = {'pending': True}
            j.save()
            import os
            os.close(j.lock)
            restored = hw.Journal(path, {'device': 1})
            self.assertEqual(restored.rules, {'8': {'pending': True}})
            os.close(restored.lock)
            with self.assertRaises(RuntimeError):
                hw.Journal(path, {'device': 2})

    def test_ctypes_match_system_uapi(self):
        source = '''#include <stddef.h>
#include <stdio.h>
#include <linux/ethtool.h>
int main(void) { printf("%zu %zu %zu %zu\\n", sizeof(struct ethtool_rx_flow_spec),
sizeof(struct ethtool_rxnfc), offsetof(struct ethtool_rx_flow_spec, ring_cookie),
offsetof(struct ethtool_rxnfc, fs)); }
'''
        with tempfile.TemporaryDirectory() as directory:
            c = Path(directory) / 'abi.c'
            exe = Path(directory) / 'abi'
            c.write_text(source)
            subprocess.run(['cc', str(c), '-o', str(exe)], check=True)
            actual = tuple(map(int, subprocess.check_output([str(exe)]).split()))
        self.assertEqual(actual, (ctypes.sizeof(hw.FlowSpec), ctypes.sizeof(hw.Rxnfc),
                                  hw.FlowSpec.queue.offset, hw.Rxnfc.fs.offset))


if __name__ == '__main__':
    unittest.main()
