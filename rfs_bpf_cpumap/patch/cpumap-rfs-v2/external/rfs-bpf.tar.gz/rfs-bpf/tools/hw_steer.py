#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0
"""Reconcile BPF socket CPU intents with an explicitly reserved RXNFC range.

RXNFC has no owner token or compare-and-swap. The reserved range MUST have a
single cooperating writer. This tool does not claim to arbitrate other writers.
Hardware steering changes RX queues, never bypasses the software barrier.
"""
import argparse
import ctypes as C
import errno
import fcntl
import json
import math
import os
from pathlib import Path
import platform
import signal
import socket
import struct
import subprocess
import tempfile
import time


class FlowUnion(C.Union):
    _fields_ = [('raw', C.c_ubyte * 52), ('align', C.c_uint32 * 13)]


class FlowSpec(C.Structure):
    _fields_ = [('flow_type', C.c_uint32), ('header', FlowUnion),
                ('header_ext', C.c_ubyte * 20), ('mask', FlowUnion),
                ('mask_ext', C.c_ubyte * 20), ('queue', C.c_uint64),
                ('location', C.c_uint32)]


class Rxnfc(C.Structure):
    _fields_ = [('cmd', C.c_uint32), ('flow_type', C.c_uint32),
                ('data', C.c_uint64), ('fs', FlowSpec), ('count', C.c_uint32)]


def spec_bytes(spec):
    """Ignore C padding, retain every selector/mask and the queue and location."""
    result = FlowSpec()
    result.flow_type = spec.flow_type
    result.header = spec.header
    result.header_ext = spec.header_ext
    result.mask = spec.mask
    result.mask_ext = spec.mask_ext
    result.queue = spec.queue
    result.location = spec.location
    return bytes(result)


def make_rule(key, queue, location):
    if len(key) != 40 or key[39]:
        raise ValueError('invalid flow key')
    family = struct.unpack_from('=H', key, 36)[0]
    protocol = key[38]
    flow_types = {6: (1, 5), 17: (2, 6), 132: (3, 7)}
    if family not in (socket.AF_INET, socket.AF_INET6) or protocol not in flow_types:
        raise ValueError('unsupported address family or protocol')
    spec = FlowSpec()
    spec.flow_type = flow_types[protocol][family == socket.AF_INET6]
    match = key[:4] + key[16:20] + key[32:36] if family == socket.AF_INET else key[:36]
    for index, byte in enumerate(match):
        spec.header.raw[index] = byte
        spec.mask.raw[index] = 255
    spec.queue, spec.location = queue, location
    return spec_bytes(spec)


class Ethtool:
    def __init__(self, device):
        if len(device.encode()) >= 16:
            raise ValueError('interface name is too long')
        self.device = device
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.libc = C.CDLL(None, use_errno=True)
        self.libc.ioctl.argtypes = [C.c_int, C.c_ulong, C.c_void_p]

    def request(self, request):
        ifreq = C.create_string_buffer(40)
        ifreq.raw = struct.pack('16sP', self.device.encode(), C.addressof(request)).ljust(40, b'\0')
        if self.libc.ioctl(self.sock.fileno(), 0x8946, ifreq) < 0:
            error = C.get_errno()
            raise OSError(error, os.strerror(error))
        return request

    def rings(self):
        return self.request(Rxnfc(cmd=0x2d)).data

    def capacity(self):
        return self.request(Rxnfc(cmd=0x2e)).data & 0x7fffffff

    def get(self, location):
        request = Rxnfc(cmd=0x2f)
        request.fs.location = location
        try:
            self.request(request)
        except OSError as error:
            # EINVAL is used by several RXNFC drivers for an empty valid slot.
            if error.errno in (errno.ENOENT, errno.EINVAL):
                return None
            raise
        return spec_bytes(request.fs)

    def put(self, rule):
        request = Rxnfc(cmd=0x32)
        request.fs = FlowSpec.from_buffer_copy(rule)
        self.request(request)
        if request.fs.location != FlowSpec.from_buffer_copy(rule).location:
            raise RuntimeError('driver changed an explicit rule location')

    def delete(self, location):
        request = Rxnfc(cmd=0x31)
        request.fs.location = location
        self.request(request)

    def identity(self):
        # A changed namespace/device/ring count requires explicit reconciliation.
        driver = C.create_string_buffer(196)
        struct.pack_into('=I', driver, 0, 3)
        self.request(driver)
        return {'netns': os.stat('/proc/self/ns/net').st_ino,
                'ifindex': socket.if_nametoindex(self.device), 'name': self.device,
                'driver': bytes(driver)[4:36].split(b'\0')[0].decode(),
                'bus': bytes(driver)[100:132].split(b'\0')[0].decode(),
                'address': Path('/sys/class/net', self.device, 'address').read_text().strip(),
                'rings': self.rings()}


class BpfMap:
    """Small bpf(2) wrapper; reject unfamiliar map layouts before accessing them."""
    def __init__(self, path, key_size, value_size, map_type, readonly=False):
        numbers = {'x86_64': 321, 'aarch64': 280, 'riscv64': 280}
        if platform.machine() not in numbers or C.sizeof(C.c_void_p) != 8:
            raise RuntimeError('controller bpf syscall binding requires a supported 64-bit host')
        self.nr = numbers[platform.machine()]
        self.libc = C.CDLL(None, use_errno=True)
        self.libc.syscall.restype = C.c_long
        pathname = C.create_string_buffer(os.fsencode(path))
        self.fd = self.call(7, struct.pack('=QII', C.addressof(pathname), 0, 8 if readonly else 0))
        info = C.create_string_buffer(256)
        try:
            self.call(15, struct.pack('=IIQ', self.fd, len(info), C.addressof(info)))
            kind, self.id, actual_key, actual_value, self.limit, _ = struct.unpack_from('=6I', info)
            if (kind, actual_key, actual_value) != (map_type, key_size, value_size):
                raise ValueError('pinned map layout/ABI mismatch: ' + str(path))
        except BaseException:
            os.close(self.fd)
            raise
        self.key_size, self.value_size = key_size, value_size

    def call(self, command, data):
        attr = C.create_string_buffer(data)
        result = self.libc.syscall(C.c_long(self.nr), C.c_int(command),
                                   C.cast(attr, C.c_void_p), C.c_uint(len(data)))
        if result < 0:
            error = C.get_errno()
            raise OSError(error, os.strerror(error))
        return result

    def lookup(self, key, locked=False):
        keybuf = C.create_string_buffer(key)
        value = C.create_string_buffer(self.value_size)
        self.call(1, struct.pack('=IIQQQ', self.fd, 0, C.addressof(keybuf),
                                 C.addressof(value), 4 if locked else 0))
        return value.raw

    def delete(self, key):
        keybuf = C.create_string_buffer(key)
        self.call(3, struct.pack('=IIQ', self.fd, 0, C.addressof(keybuf)))

    def entries(self):
        previous, visited = None, set()
        for _ in range(self.limit * 2):
            key = C.create_string_buffer(self.key_size)
            old = C.create_string_buffer(previous) if previous is not None else None
            try:
                self.call(4, struct.pack('=IIQQ', self.fd, 0,
                                         C.addressof(old) if old else 0, C.addressof(key)))
            except OSError as error:
                if error.errno == errno.ENOENT:
                    return
                raise
            previous = key.raw
            if previous in visited:
                continue
            visited.add(previous)
            try:
                yield previous, self.lookup(previous, locked=True)
            except OSError as error:
                if error.errno != errno.ENOENT:
                    raise


class Journal:
    def __init__(self, path, identity):
        self.path = Path(path)
        self.lock = os.open(str(path) + '.lock', os.O_RDWR | os.O_CREAT | os.O_CLOEXEC |
                            os.O_NOFOLLOW, 0o600)
        fcntl.flock(self.lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        self.identity = identity
        self.rules = {}
        if self.path.exists():
            if self.path.is_symlink():
                raise ValueError('journal must not be a symlink')
            document = json.loads(self.path.read_text())
            if document['version'] != 1 or document['identity'] != identity:
                raise RuntimeError('journal belongs to another device epoch; manual review required')
            self.rules = document['rules']

    def save(self):
        data = json.dumps({'version': 1, 'identity': self.identity, 'rules': self.rules},
                          sort_keys=True).encode() + b'\n'
        fd, temporary = tempfile.mkstemp(dir=self.path.parent, prefix=self.path.name + '.')
        try:
            with os.fdopen(fd, 'wb') as output:
                output.write(data)
                output.flush()
                os.fsync(output.fileno())
            os.replace(temporary, self.path)
            directory = os.open(self.path.parent, os.O_DIRECTORY | os.O_RDONLY)
            try:
                os.fsync(directory)
            finally:
                os.close(directory)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)


class Controller:
    def __init__(self, backend, journal, locations, queues):
        self.backend, self.journal = backend, journal
        self.locations, self.queues = list(locations), queues
        self.conflicts = set()
        self.counters = {'installed': 0, 'deleted': 0, 'full': 0, 'conflict': 0}
        if any(int(location) not in self.locations for location in journal.rules):
            raise ValueError('journal contains rules outside the selected range')

    def remove(self, location):
        entry = self.journal.rules[str(location)]
        actual = self.backend.get(location)
        if actual is not None and actual.hex() != entry['spec']:
            self.conflicts.add(location)
            self.counters['conflict'] += 1
            raise RuntimeError('foreign/changed rule at location ' + str(location))
        if actual is not None:
            self.backend.delete(location)
            if self.backend.get(location) is not None:
                raise RuntimeError('rule deletion has not been confirmed')
        del self.journal.rules[str(location)]
        self.journal.save()
        self.counters['deleted'] += 1

    def recover(self):
        # Includes pending insertions left by a crash or a failed readback.
        for location in list(self.journal.rules):
            self.remove(int(location))

    def recover_device(self, identity):
        if self.backend.identity() != identity:
            raise RuntimeError('device identity changed; preserve journal for manual recovery')
        self.recover()

    def reconcile(self, intents):
        """intents: key bytes -> (CPU, generation); a snapshot, not authority."""
        desired = {key: (self.queues[cpu], gen) for key, (cpu, gen) in intents.items()
                   if cpu in self.queues}
        for loc, entry in list(self.journal.rules.items()):
            location = int(loc)
            key = bytes.fromhex(entry['key'])
            target = desired.get(key)
            expected = make_rule(key, target[0], location) if target else None
            if expected is None or expected.hex() != entry['spec']:
                self.remove(location)
            elif self.backend.get(location) != expected:
                # A reset may have removed the rule. A foreign replacement is
                # retained and reported, never overwritten or garbage-collected.
                self.remove(location)
            elif entry['generation'] != target[1] or entry['state'] != 'active':
                entry['generation'], entry['state'] = target[1], 'active'
                self.journal.save()
        active = {bytes.fromhex(entry['key']) for entry in self.journal.rules.values()}
        budget = 16
        for key, (queue, generation) in desired.items():
            if key in active:
                continue
            if not budget:
                break
            location = None
            for loc in self.locations:
                if str(loc) in self.journal.rules or loc in self.conflicts:
                    continue
                if self.backend.get(loc) is None:
                    location = loc
                    break
                self.conflicts.add(loc)
                self.counters['conflict'] += 1
            if location is None:
                self.counters['full'] += 1
                continue
            rule = make_rule(key, queue, location)
            self.journal.rules[str(location)] = {
                'key': key.hex(), 'spec': rule.hex(), 'generation': generation, 'state': 'pending'}
            # Durable intent BEFORE the ioctl makes even uncertain failures recoverable.
            self.journal.save()
            self.backend.put(rule)
            if self.backend.get(location) != rule:
                raise RuntimeError('driver did not confirm the requested rule')
            self.journal.rules[str(location)]['state'] = 'active'
            self.journal.save()
            self.counters['installed'] += 1
            budget -= 1


def cpu_queues(text):
    pairs = [tuple(map(int, item.split(':'))) for item in text.split(',')]
    if any(len(pair) != 2 or min(pair) < 0 for pair in pairs) or len(dict(pairs)) != len(pairs):
        raise ValueError('use distinct CPU:QUEUE pairs')
    return dict(pairs)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--device', required=True)
    parser.add_argument('--maps', type=Path, required=True)
    parser.add_argument('--cpu-queues', type=cpu_queues, required=True)
    parser.add_argument('--locations', required=True, help='FIRST:COUNT exclusively reserved by operator')
    parser.add_argument('--journal', type=Path, required=True)
    parser.add_argument('--exclusive-range', action='store_true', required=True)
    parser.add_argument('--interval', type=float, default=1.0)
    parser.add_argument('--idle', type=float, default=30.0)
    parser.add_argument('--recover-only', action='store_true')
    args = parser.parse_args()
    first, count = map(int, args.locations.split(':'))
    if (first < 0 or not 1 <= count <= 1024 or
            not math.isfinite(args.interval) or not math.isfinite(args.idle) or
            args.interval < 0.25 or args.idle < 1):
        parser.error('invalid range, poll interval, or idle lifetime')
    backend = Ethtool(args.device)
    identity = backend.identity()
    # One controller per interface, even with different journal paths/ranges.
    lockpath = '/run/rfs-bpf-rxnfc-%d-%d.lock' % (identity['netns'], identity['ifindex'])
    device_lock = os.open(lockpath, os.O_RDWR | os.O_CREAT | os.O_CLOEXEC | os.O_NOFOLLOW, 0o600)
    fcntl.flock(device_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    if first + count > backend.capacity() or any(q >= identity['rings'] for q in args.cpu_queues.values()):
        parser.error('rule location or RX queue is outside device capacity')
    journal = Journal(args.journal, identity)
    controller = Controller(backend, journal, range(first, first + count), args.cpu_queues)
    controller.recover_device(identity)
    if args.recover_only:
        return
    flows = BpfMap(args.maps / 'flows', 40, 24, 1)
    allowed = BpfMap(args.maps / 'allowed', 4, 4, 2, readonly=True)
    config = BpfMap(args.maps / 'config', 4, 16, 2, readonly=True)
    abi, ifindex, netns, program = struct.unpack('=4I', config.lookup(struct.pack('=I', 0)))
    if (abi, ifindex, netns) != (1, identity['ifindex'], identity['netns']):
        raise RuntimeError('maps belong to another interface/netns or incompatible ABI')
    stopped = False

    def stop(_signum, _frame):
        nonlocal stopped
        stopped = True

    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGTERM, stop)
    try:
        while not stopped:
            if backend.identity() != identity:
                raise RuntimeError('device/queue topology changed; reconcile before restarting')
            link = json.loads(subprocess.check_output(['ip', '-j', '-d', 'link', 'show', 'dev', args.device]))[0]
            xdp = link.get('xdp', {})
            if xdp.get('prog', {}).get('id') != program:
                raise RuntimeError('expected XDP policy is no longer attached')
            now = time.monotonic_ns()
            intents, expired = {}, []
            for key, value in flows.entries():
                _, cpu, seen, generation = struct.unpack('=IIQQ', value)
                if now - seen > args.idle * 1e9:
                    expired.append(key)
                elif struct.unpack('=I', allowed.lookup(struct.pack('=I', cpu)))[0]:
                    intents[key] = (cpu, generation)
            controller.reconcile(intents)
            for key in expired:
                try:
                    if now - struct.unpack('=IIQQ', flows.lookup(key, locked=True))[2] > args.idle * 1e9:
                        flows.delete(key)
                except OSError as error:
                    if error.errno != errno.ENOENT:
                        raise
            print(json.dumps(controller.counters), flush=True)
            time.sleep(args.interval)
    finally:
        # If deletion fails the durable record remains; never declare cleanup done.
        controller.recover_device(identity)


if __name__ == '__main__':
    main()
